`timescale 1ns/1ps
// Runs the DMA on a DDR image produced by the C driver code (sw/gen_vectors.c) and compares the results
// with the C reference model. Proves the software data layout / descriptor format matches the RTL.
module tb_swvec;
    parameter NTILES = 16;
    localparam MEMW = 1 << 17;

    reg clk = 0, rst = 1;
    always #5 clk = ~clk;

    reg  [2:0]  csr_address = 0;
    reg         csr_read = 0, csr_write = 0;
    reg  [31:0] csr_writedata = 0;
    wire [31:0] csr_readdata;
    wire        csr_waitrequest, irq;
    wire [31:0] dma_address;
    wire        dma_read, dma_write, dma_readdatavalid, dma_waitrequest, dma_writeresponsevalid;
    wire [63:0] dma_writedata, dma_readdata;
    wire [7:0]  dma_byteenable;

    npu_soc_top dut (
        .clk(clk), .reset(rst),
        .csr_address(csr_address), .csr_read(csr_read), .csr_write(csr_write),
        .csr_writedata(csr_writedata), .csr_readdata(csr_readdata), .csr_waitrequest(csr_waitrequest),
        .dma_address(dma_address), .dma_read(dma_read), .dma_write(dma_write),
        .dma_writedata(dma_writedata), .dma_byteenable(dma_byteenable),
        .dma_readdata(dma_readdata), .dma_readdatavalid(dma_readdatavalid),
        .dma_waitrequest(dma_waitrequest), .dma_writeresponsevalid(dma_writeresponsevalid), .irq(irq));

    reg [63:0] mem [0:MEMW-1];
    reg [63:0] expw [0:NTILES*8-1];
    reg        wait_r = 0, rv = 0, wrv = 0;
    reg [63:0] rd = 0;
    assign dma_waitrequest = wait_r;
    assign dma_readdatavalid = rv;
    assign dma_readdata = rd;
    assign dma_writeresponsevalid = wrv;

    always @(negedge clk) wait_r <= (($urandom % 100) < 25);
    always @(posedge clk) begin
        rv <= 0; wrv <= 0;
        if (dma_read && !wait_r)  begin rd <= mem[dma_address[31:3]]; rv <= 1; end
        if (dma_write && !wait_r) begin mem[dma_address[31:3]] <= dma_writedata; wrv <= 1; end
    end

    task csr_wr(input [2:0] a, input [31:0] d);
        begin
            @(negedge clk); csr_address = a; csr_writedata = d; csr_write = 1;
            @(negedge clk); csr_write = 0;
        end
    endtask

    integer i, errors = 0, w;
    initial begin
        $readmemh("sim/sw_mem.hex", mem);
        $readmemh("sim/sw_exp.hex", expw);
        repeat (5) @(negedge clk); rst = 0; repeat (3) @(negedge clk);
        csr_wr(3'd1, 32'h0);
        csr_wr(3'd2, NTILES);
        csr_wr(3'd0, 32'h3);
        w = 0;
        while (!irq && w < 200000) begin @(negedge clk); w = w + 1; end
        if (w >= 200000) begin $display("FAIL: timeout"); errors = errors + 1; end
        repeat (4) @(negedge clk);
        for (i = 0; i < NTILES*8; i = i + 1)
            if (mem[(32'h80000 >> 3) + i] !== expw[i]) begin
                if (errors < 10) $display("FAIL: word %0d = %h expected %h", i, mem[(32'h80000 >> 3) + i], expw[i]);
                errors = errors + 1;
            end
        if (errors == 0) $display("PASS: %0d tiles from the C driver layout match the C reference model", NTILES);
        else             $display("FAIL: %0d mismatches", errors);
        $finish;
    end
    initial begin #100_000_000; $display("FAIL: global timeout"); $finish; end
endmodule

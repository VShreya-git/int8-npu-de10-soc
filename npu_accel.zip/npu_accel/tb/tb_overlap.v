`timescale 1ns/1ps
// Throughput comparison: single-buffered v1 core vs. double-buffered core, identical stimulus.
// T back-to-back tiles streamed at one beat per cycle into an always-ready sink.
// Also checks that both cores produce identical output data.
module tb_overlap;
    localparam N = 8, KMAX = 32;
    parameter T = 16;
    parameter K = 32;

    reg clk = 0, rst = 1;
    always #5 clk = ~clk;

    reg  [63:0] s_tdata;
    reg         s_tvalid = 0, s_tlast;
    wire        s1_ready, s2_ready;
    wire [63:0] m1_data, m2_data;
    wire        m1_valid, m2_valid, m1_last, m2_last;
    wire        busy1, busy2, d1, d2, e1, e2;
    wire [31:0] p1, p2;

    reg [4:0]   shift = 9;
    reg [255:0] bias  = {8{32'd100}};

    npu_core_v1 #(.N(N), .KMAX(KMAX)) c1 (
        .clk(clk), .rst(rst), .cfg_relu(1'b1), .cfg_shift(shift), .cfg_klen(K[7:0]), .cfg_bias(bias),
        .s_tdata(s_tdata), .s_tvalid(s_tvalid), .s_tready(s1_ready), .s_tlast(s_tlast),
        .m_tdata(m1_data), .m_tvalid(m1_valid), .m_tready(1'b1), .m_tlast(m1_last),
        .busy(busy1), .done_pulse(d1), .err_pulse(e1), .perf_cycles(p1));

    npu_core    #(.N(N), .KMAX(KMAX)) c2 (
        .clk(clk), .rst(rst), .cfg_relu(1'b1), .cfg_shift(shift), .cfg_klen(K[7:0]), .cfg_bias(bias),
        .s_tdata(s_tdata), .s_tvalid(s_tvalid), .s_tready(s2_ready), .s_tlast(s_tlast),
        .m_tdata(m2_data), .m_tvalid(m2_valid), .m_tready(1'b1), .m_tlast(m2_last),
        .busy(busy2), .done_pulse(d2), .err_pulse(e2), .perf_cycles(p2));

    // Each core is driven by its own source copy so a slow core cannot stall the other.
    // The source is a pure function of (tile, beat), so both see identical data.
    function [63:0] beat_data(input integer tile, input integer beat);
        integer b;
        reg [63:0] v;
        begin
            v = 0;
            for (b = 0; b < 8; b = b + 1) v[b*8 +: 8] = (tile * 31 + beat * 7 + b * 13 + 5) % 251 - 125;
            beat_data = v;
        end
    endfunction

    integer cycles1 = 0, cycles2 = 0, done1 = 0, done2 = 0, mism = 0;
    integer n1 = 0, b1 = 0, n2 = 0, b2 = 0;
    reg [63:0] rec1 [0:T*N-1];
    reg [63:0] rec2 [0:T*N-1];
    integer o1 = 0, o2 = 0;

    // The two cores need independent stream sources, so generate stimulus per core with a small wrapper:
    // a shared s_tdata/s_tvalid would let the slower core's backpressure disturb the other one. Instead each
    // core is simulated in its own phase (same testbench, run twice) - see `phase`.
    integer phase = 0;

    reg sel2;                       // which core is currently being fed
    wire s_ready = sel2 ? s2_ready : s1_ready;

    integer tile, beat, started;
    task feed;
        integer tl, bt;
        begin
            for (tl = 0; tl < T; tl = tl + 1)
                for (bt = 0; bt < 2*K; bt = bt + 1) begin
                    @(negedge clk);
                    s_tvalid = 1; s_tdata = beat_data(tl, bt); s_tlast = (bt == 2*K - 1);
                    #1;
                    while (!s_ready) begin @(negedge clk); #1; end
                end
            @(negedge clk); s_tvalid = 0; s_tlast = 0;
        end
    endtask

    integer t0;
    initial begin
        repeat (4) @(negedge clk); rst = 0; repeat (2) @(negedge clk);

        // ---- phase 1: v1 core
        sel2 = 0; o1 = 0; t0 = $time / 10;
        fork
            feed;
            begin : mon1
                while (o1 < T*N) begin
                    @(posedge clk);
                    if (m1_valid) begin rec1[o1] = m1_data; o1 = o1 + 1; end
                end
            end
        join
        cycles1 = $time / 10 - t0;

        // ---- reset both, phase 2: double-buffered core
        rst = 1; repeat (3) @(negedge clk); rst = 0; repeat (3) @(negedge clk);
        sel2 = 1; o2 = 0; t0 = $time / 10;
        fork
            feed;
            begin : mon2
                while (o2 < T*N) begin
                    @(posedge clk);
                    if (m2_valid) begin rec2[o2] = m2_data; o2 = o2 + 1; end
                end
            end
        join
        cycles2 = $time / 10 - t0;

        for (tile = 0; tile < T*N; tile = tile + 1) if (rec1[tile] !== rec2[tile]) mism = mism + 1;

        $display("----------------------------------------");
        $display("%0d back-to-back tiles, K=%0d (2K = %0d input beats per tile):", T, K, 2*K);
        $display("  single-buffered core : %0d cycles  (%0d cycles/tile)", cycles1, cycles1 / T);
        $display("  double-buffered core : %0d cycles  (%0d cycles/tile)", cycles2, cycles2 / T);
        $display("  speedup              : %0d.%02dx", (cycles1*100/cycles2)/100, (cycles1*100/cycles2)%100);
        if (mism == 0) $display("PASS: both cores produced identical output data (%0d beats)", T*N);
        else           $display("FAIL: %0d output beats differ", mism);
        $display("----------------------------------------");
        $finish;
    end

    initial begin #50_000_000; $display("FAIL: timeout"); $finish; end
endmodule

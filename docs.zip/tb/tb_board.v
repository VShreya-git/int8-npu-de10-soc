`timescale 1ns/1ps
// Board-top smoke test: reset, press KEY1, expect PASS LED; run twice to check re-runnability.
module tb_board;
    reg clk = 0;
    reg [3:0] key = 4'b1111;
    wire [9:0] ledr;
    de10_npu_top dut (.CLOCK_50(clk), .KEY(key), .LEDR(ledr));
    always #10 clk = ~clk;

    integer run, w, errors = 0;
    initial begin
        repeat (5) @(posedge clk);
        key[0] = 0; repeat (10) @(posedge clk); key[0] = 1;
        repeat (10) @(posedge clk);
        for (run = 0; run < 2; run = run + 1) begin
            key[1] = 0; repeat (10) @(posedge clk); key[1] = 1;
            w = 0;
            while (!(ledr[9] || ledr[8]) && w < 5000) begin @(posedge clk); w = w + 1; end
            if (ledr[9] && !ledr[8] && !ledr[0]) $display("PASS: run %0d BIST PASS LED after %0d cycles", run, w);
            else begin $display("FAIL: run %0d LEDR=%b after %0d cycles", run, ledr, w); errors = errors + 1; end
            repeat (20) @(posedge clk);
        end
        $finish;
    end
endmodule

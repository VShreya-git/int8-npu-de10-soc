`timescale 1ns/1ps

// Self-checking testbench for npu_top.
//  1. directed corner cases (K=1, K=KMAX, saturation both ways, ReLU, rounding shifts)
//  2. randomized tiles: random K / shift / relu / bias, random AXI-Stream stalls on both channels
//  3. tiled 16x24x16 layer (four 8x8 output tiles) compared against an independent full-matrix model
//  4. protocol error handling (short packet, bad K) and recovery
module tb_npu;
    localparam N = 8, KMAX = 32;
    parameter NUM_RANDOM = 300;

    reg clk = 0, rst = 1;
    always #5 clk = ~clk;

    // APB
    reg         psel = 0, penable = 0, pwrite = 0;
    reg  [7:0]  paddr = 0;
    reg  [31:0] pwdata = 0;
    wire [31:0] prdata;
    wire        pready, pslverr;
    // AXI-Stream
    reg  [N*8-1:0] s_tdata = 0;
    reg            s_tvalid = 0, s_tlast = 0;
    wire           s_tready;
    wire [N*8-1:0] m_tdata;
    wire           m_tvalid, m_tlast;
    reg            m_tready = 0;

    npu_top #(.N(N), .KMAX(KMAX)) dut (
        .clk(clk), .rst(rst),
        .psel(psel), .penable(penable), .pwrite(pwrite), .paddr(paddr), .pwdata(pwdata),
        .prdata(prdata), .pready(pready), .pslverr(pslverr),
        .s_axis_tdata(s_tdata), .s_axis_tvalid(s_tvalid), .s_axis_tready(s_tready), .s_axis_tlast(s_tlast),
        .m_axis_tdata(m_tdata), .m_axis_tvalid(m_tvalid), .m_axis_tready(m_tready), .m_axis_tlast(m_tlast));

    integer errors = 0, tests = 0;
    integer bp_en  = 1;                     // random stalls on/off

    // ------------------------------------------------------------ helpers
    function integer rs8(input integer dummy);
        begin rs8 = ($urandom % 256) - 128; end
    endfunction

    function integer qref(input integer acc, input integer bias, input integer sh, input integer relu);
        integer v;
        begin
            v = acc + bias;
            if (sh > 0) v = (v + (1 << (sh - 1))) >>> sh;
            if (relu != 0 && v < 0) v = 0;
            if (v > 127)  v = 127;
            if (v < -128) v = -128;
            qref = v;
        end
    endfunction

    task apb_write(input [7:0] a, input [31:0] d);
        begin
            @(negedge clk); psel = 1; penable = 0; pwrite = 1; paddr = a; pwdata = d;
            @(negedge clk); penable = 1;
            @(negedge clk); psel = 0; penable = 0; pwrite = 0;
        end
    endtask

    task apb_read(input [7:0] a, output [31:0] d);
        begin
            @(negedge clk); psel = 1; penable = 0; pwrite = 0; paddr = a;
            @(negedge clk); penable = 1;
            #1 d = prdata;
            @(negedge clk); psel = 0; penable = 0;
        end
    endtask

    // drive one AXI-Stream beat; optional random idle gaps before it
    task send_beat(input [N*8-1:0] d, input last);
        reg acc;
        begin
            while (bp_en && ($urandom % 4 == 0)) begin
                s_tvalid = 0; @(negedge clk);
            end
            s_tvalid = 1; s_tdata = d; s_tlast = last;
            acc = 0;
            while (!acc) begin
                #1 acc = s_tready;          // ready only changes right after posedge, so this is exact
                @(posedge clk);
                @(negedge clk);
            end
            s_tvalid = 0; s_tlast = 0;
        end
    endtask

    // random output-side backpressure
    always @(negedge clk) m_tready <= bp_en ? (($urandom % 4) != 0) : 1'b1;

    // output monitor
    reg [N*8-1:0] obeat [0:127];
    integer ocnt = 0, tlast_bad = 0, extra_beats = 0, expect_beats = N;
    always @(posedge clk) if (m_tvalid && m_tready) begin
        if (ocnt < 128) obeat[ocnt] = m_tdata;
        if (ocnt >= expect_beats) extra_beats = extra_beats + 1;
        if (m_tlast !== ((ocnt % N) == N - 1)) tlast_bad = tlast_bad + 1;
        ocnt = ocnt + 1;
    end

    // ------------------------------------------------------------ tile run + check
    integer tA [0:N-1][0:KMAX-1];
    integer tW [0:KMAX-1][0:N-1];
    integer tbias [0:N-1];
    integer tout [0:N-1][0:N-1];

    task run_tile(input integer K, input integer relu, input integer sh);
        integer r, k, c, timeout;
        reg [N*8-1:0] d;
        begin
            apb_write(8'h00, relu);
            apb_write(8'h04, sh);
            apb_write(8'h08, K);
            for (c = 0; c < N; c = c + 1) apb_write(8'h10 + 4*c, tbias[c]);
            ocnt = 0; tlast_bad = 0; extra_beats = 0;
            for (k = 0; k < K; k = k + 1) begin
                d = 0;
                for (r = 0; r < N; r = r + 1) d[r*8 +: 8] = tA[r][k];
                send_beat(d, 1'b0);
            end
            for (k = 0; k < K; k = k + 1) begin
                d = 0;
                for (c = 0; c < N; c = c + 1) d[c*8 +: 8] = tW[k][c];
                send_beat(d, k == K - 1);
            end
            timeout = 0;
            while (ocnt < N && timeout < 2000) begin @(negedge clk); timeout = timeout + 1; end
            repeat (4) @(negedge clk);
            if (ocnt != N) begin
                $display("FAIL: output timeout (got %0d beats)", ocnt); errors = errors + 1;
            end else begin
                for (r = 0; r < N; r = r + 1)
                    for (c = 0; c < N; c = c + 1)
                        tout[r][c] = $signed(obeat[r][c*8 +: 8]);
            end
            if (tlast_bad != 0 || extra_beats != 0) begin
                $display("FAIL: stream framing (tlast_bad=%0d extra=%0d)", tlast_bad, extra_beats);
                errors = errors + 1;
            end
        end
    endtask

    task check_tile(input integer K, input integer relu, input integer sh, input [255:0] name);
        integer r, c, k, acc, exp;
        begin
            for (r = 0; r < N; r = r + 1)
                for (c = 0; c < N; c = c + 1) begin
                    acc = 0;
                    for (k = 0; k < K; k = k + 1) acc = acc + tA[r][k] * tW[k][c];
                    exp = qref(acc, tbias[c], sh, relu);
                    if (tout[r][c] !== exp) begin
                        if (errors < 20)
                            $display("FAIL [%0s] K=%0d sh=%0d relu=%0d out[%0d][%0d]=%0d expected %0d",
                                     name, K, sh, relu, r, c, tout[r][c], exp);
                        errors = errors + 1;
                    end
                end
            tests = tests + 1;
        end
    endtask

    task fill_random(input integer K);
        integer r, k, c;
        begin
            for (r = 0; r < N; r = r + 1) for (k = 0; k < K; k = k + 1) tA[r][k] = rs8(0);
            for (k = 0; k < K; k = k + 1) for (c = 0; c < N; c = c + 1) tW[k][c] = rs8(0);
            for (c = 0; c < N; c = c + 1) tbias[c] = ($urandom % 200001) - 100000;
        end
    endtask

    task fill_const(input integer K, input integer av, input integer wv, input integer bv);
        integer r, k, c;
        begin
            for (r = 0; r < N; r = r + 1) for (k = 0; k < K; k = k + 1) tA[r][k] = av;
            for (k = 0; k < K; k = k + 1) for (c = 0; c < N; c = c + 1) tW[k][c] = wv;
            for (c = 0; c < N; c = c + 1) tbias[c] = bv;
        end
    endtask

    // ------------------------------------------------------------ tiled layer test
    integer LA [0:2*N-1][0:23];
    integer LW [0:23][0:2*N-1];
    integer LB [0:2*N-1];
    integer LC [0:2*N-1][0:2*N-1];

    task tiled_layer(input integer relu, input integer sh);
        integer mt, nt, r, c, k, acc, exp;
        begin
            for (r = 0; r < 2*N; r = r + 1) for (k = 0; k < 24; k = k + 1) LA[r][k] = rs8(0);
            for (k = 0; k < 24; k = k + 1) for (c = 0; c < 2*N; c = c + 1) LW[k][c] = rs8(0);
            for (c = 0; c < 2*N; c = c + 1) LB[c] = ($urandom % 20001) - 10000;
            for (mt = 0; mt < 2; mt = mt + 1)
                for (nt = 0; nt < 2; nt = nt + 1) begin
                    for (r = 0; r < N; r = r + 1) for (k = 0; k < 24; k = k + 1) tA[r][k] = LA[mt*N + r][k];
                    for (k = 0; k < 24; k = k + 1) for (c = 0; c < N; c = c + 1) tW[k][c] = LW[k][nt*N + c];
                    for (c = 0; c < N; c = c + 1) tbias[c] = LB[nt*N + c];
                    run_tile(24, relu, sh);
                    for (r = 0; r < N; r = r + 1) for (c = 0; c < N; c = c + 1) LC[mt*N + r][nt*N + c] = tout[r][c];
                end
            for (r = 0; r < 2*N; r = r + 1)
                for (c = 0; c < 2*N; c = c + 1) begin
                    acc = 0;
                    for (k = 0; k < 24; k = k + 1) acc = acc + LA[r][k] * LW[k][c];
                    exp = qref(acc, LB[c], sh, relu);
                    if (LC[r][c] !== exp) begin
                        if (errors < 20) $display("FAIL [tiled] C[%0d][%0d]=%0d expected %0d", r, c, LC[r][c], exp);
                        errors = errors + 1;
                    end
                end
            tests = tests + 1;
        end
    endtask

    // ------------------------------------------------------------ overlapped back-to-back tiles
    integer oA [0:11][0:N-1][0:KMAX-1];
    integer oW [0:11][0:KMAX-1][0:N-1];
    integer oB [0:11][0:N-1];
    integer oK [0:11];
    integer oS [0:11];
    integer oR [0:11];

    task overlap_test(input integer T);
        integer n, r, k, c, acc, exp, cyc0, cyc1, timeout;
        reg [N*8-1:0] d;
        begin
            for (n = 0; n < T; n = n + 1) begin
                oK[n] = 1 + ($urandom % KMAX);
                if (n % 3 == 0) oK[n] = KMAX;
                oS[n] = $urandom % 14;
                oR[n] = $urandom % 2;
                for (r = 0; r < N; r = r + 1) for (k = 0; k < oK[n]; k = k + 1) oA[n][r][k] = rs8(0);
                for (k = 0; k < oK[n]; k = k + 1) for (c = 0; c < N; c = c + 1) oW[n][k][c] = rs8(0);
                for (c = 0; c < N; c = c + 1) oB[n][c] = ($urandom % 20001) - 10000;
            end
            ocnt = 0; tlast_bad = 0; extra_beats = 0; expect_beats = T * N;
            cyc0 = $time / 10;
            for (n = 0; n < T; n = n + 1) begin
                // program this tile's configuration right before its first beat
                apb_write(8'h00, oR[n]); apb_write(8'h04, oS[n]); apb_write(8'h08, oK[n]);
                for (c = 0; c < N; c = c + 1) apb_write(8'h10 + 4*c, oB[n][c]);
                for (k = 0; k < oK[n]; k = k + 1) begin
                    d = 0; for (r = 0; r < N; r = r + 1) d[r*8 +: 8] = oA[n][r][k];
                    send_beat(d, 1'b0);
                end
                for (k = 0; k < oK[n]; k = k + 1) begin
                    d = 0; for (c = 0; c < N; c = c + 1) d[c*8 +: 8] = oW[n][k][c];
                    send_beat(d, k == oK[n] - 1);
                end
            end
            timeout = 0;
            while (ocnt < T * N && timeout < 20000) begin @(negedge clk); timeout = timeout + 1; end
            cyc1 = $time / 10;
            repeat (4) @(negedge clk);
            if (ocnt != T * N || tlast_bad != 0 || extra_beats != 0) begin
                $display("FAIL: overlap test framing (ocnt=%0d tlast_bad=%0d extra=%0d)", ocnt, tlast_bad, extra_beats);
                errors = errors + 1;
            end
            for (n = 0; n < T; n = n + 1)
                for (r = 0; r < N; r = r + 1)
                    for (c = 0; c < N; c = c + 1) begin
                        acc = 0;
                        for (k = 0; k < oK[n]; k = k + 1) acc = acc + oA[n][r][k] * oW[n][k][c];
                        exp = qref(acc, oB[n][c], oS[n], oR[n]);
                        if ($signed(obeat[n*N + r][c*8 +: 8]) !== exp) begin
                            if (errors < 20) $display("FAIL [overlap] tile %0d out[%0d][%0d]=%0d expected %0d",
                                                      n, r, c, $signed(obeat[n*N + r][c*8 +: 8]), exp);
                            errors = errors + 1;
                        end
                    end
            tests = tests + 1;
            expect_beats = N;
            $display("INFO: %0d overlapped tiles (stalls %0s) finished in %0d cycles", T, bp_en ? "on" : "off", cyc1 - cyc0);
        end
    endtask

    // ------------------------------------------------------------ main
    integer i, t, K, sh, rl;
    reg [31:0] rd;

    initial begin
        $dumpfile("sim/tb_npu.vcd");
        $dumpvars(0, tb_npu);
        repeat (5) @(negedge clk);
        rst = 0;
        repeat (3) @(negedge clk);

        // --- register read-back sanity
        apb_read(8'h08, rd);
        if (rd !== 32'd8) begin $display("FAIL: KLEN reset value %0d", rd); errors = errors + 1; end
        apb_write(8'h14, 32'hDEADBEEF);
        apb_read(8'h14, rd);
        if (rd !== 32'hDEADBEEF) begin $display("FAIL: BIAS[1] readback %h", rd); errors = errors + 1; end

        // --- directed corner cases (no stalls first, then stalls)
        for (i = 0; i < 2; i = i + 1) begin
            bp_en = i;
            fill_const(1, 5, 7, 0);        run_tile(1, 0, 0);   check_tile(1, 0, 0, "K1");
            fill_const(KMAX, -128, -128, 0); run_tile(KMAX, 0, 0); check_tile(KMAX, 0, 0, "satpos");
            fill_const(KMAX, 127, -128, 0);  run_tile(KMAX, 0, 0); check_tile(KMAX, 0, 0, "satneg");
            fill_const(KMAX, 127, -128, 0);  run_tile(KMAX, 1, 0); check_tile(KMAX, 1, 0, "relu_neg");
            fill_const(4, 3, 3, 1);        run_tile(4, 0, 3);   check_tile(4, 0, 3, "round");
            fill_const(4, 0, 0, -50);      run_tile(4, 0, 0);   check_tile(4, 0, 0, "biasonly");
            fill_const(4, 1, 1, 0);        run_tile(4, 0, 31);  check_tile(4, 0, 31, "shift31");
        end

        // --- randomized tiles with random stalls
        bp_en = 1;
        for (t = 0; t < NUM_RANDOM; t = t + 1) begin
            K  = 1 + ($urandom % KMAX);
            sh = $urandom % 16;
            rl = $urandom % 2;
            fill_random(K);
            run_tile(K, rl, sh);
            check_tile(K, rl, sh, "random");
        end

        // --- tiled layer
        tiled_layer(1, 9);
        tiled_layer(0, 10);

        // --- back-to-back overlapped tiles (double buffering): per-tile cfg changes while the previous tile computes
        bp_en = 0;
        overlap_test(6);
        bp_en = 1;
        overlap_test(10);

        // --- performance counter
        fill_random(KMAX); run_tile(KMAX, 0, 8);
        bp_en = 0; run_tile(KMAX, 0, 8);
        apb_read(8'h40, rd);
        $display("INFO: tile 8x8 with K=%0d took %0d cycles (no stalls)  ->  %0d MACs/cycle average",
                 KMAX, rd, (N*N*KMAX)/rd);

        // --- error handling: short packet (tlast after 3 of 8 beats)
        bp_en = 0;
        apb_write(8'h08, 4);
        apb_write(8'h0C, 32'h6);                  // clear sticky flags
        send_beat(64'h1, 0); send_beat(64'h2, 0); send_beat(64'h3, 1);
        repeat (6) @(negedge clk);
        apb_read(8'h0C, rd);
        if (rd[2] !== 1'b1 || rd[0] !== 1'b0) begin
            $display("FAIL: short packet not flagged / core stuck busy (STATUS=%h)", rd); errors = errors + 1;
        end
        apb_write(8'h0C, 32'h6);
        apb_read(8'h0C, rd);
        if (rd[2:1] !== 2'b00) begin $display("FAIL: sticky clear (STATUS=%h)", rd); errors = errors + 1; end

        // --- error handling: invalid K (0 and > KMAX); packet swallowed, error flagged
        apb_write(8'h08, 0);
        send_beat(64'h1, 0); send_beat(64'h2, 1);
        repeat (4) @(negedge clk);
        apb_read(8'h0C, rd);
        if (rd[2] !== 1'b1) begin $display("FAIL: bad K not flagged (STATUS=%h)", rd); errors = errors + 1; end
        apb_write(8'h0C, 32'h6);

        // --- recovery: normal tile works afterwards, and done flag is set
        fill_random(10); run_tile(10, 1, 7); check_tile(10, 1, 7, "recovery");
        apb_read(8'h0C, rd);
        if (rd[1] !== 1'b1) begin $display("FAIL: done flag not set (STATUS=%h)", rd); errors = errors + 1; end

        $display("----------------------------------------");
        if (errors == 0) $display("PASS: %0d checks (tiles + tiled layers), 0 errors", tests);
        else             $display("FAIL: %0d errors in %0d checks", errors, tests);
        $display("----------------------------------------");
        $finish;
    end

    initial begin
        #500_000_000;
        $display("FAIL: global timeout");
        $finish;
    end
endmodule

`timescale 1ns/1ps

// Full-system test of npu_soc_top: a software-style flow against a DDR model.
//   * 1 MB word-addressed memory behind an Avalon-MM slave with random waitrequest,
//     random read latency (in-order) and write responses
//   * CSR programmed exactly like the Linux driver does
//   * runs (a) many random tiles incl. all K, (b) a chained 16x32x16 layer, (c) a bad descriptor, (d) back-to-back runs
module tb_soc;
    parameter MEMW = 1 << 17;                 // 1 MB in 64-bit words
    reg clk = 0, rst = 1;
    always #5 clk = ~clk;

    reg  [2:0]  csr_address = 0;
    reg         csr_read = 0, csr_write = 0;
    reg  [31:0] csr_writedata = 0;
    wire [31:0] csr_readdata;
    wire        csr_waitrequest;
    wire [31:0] dma_address;
    wire        dma_read, dma_write;
    wire [63:0] dma_writedata, dma_readdata;
    wire [7:0]  dma_byteenable;
    wire        dma_readdatavalid, dma_waitrequest, dma_writeresponsevalid;
    wire        irq;

    npu_soc_top dut (
        .clk(clk), .reset(rst),
        .csr_address(csr_address), .csr_read(csr_read), .csr_write(csr_write),
        .csr_writedata(csr_writedata), .csr_readdata(csr_readdata), .csr_waitrequest(csr_waitrequest),
        .dma_address(dma_address), .dma_read(dma_read), .dma_write(dma_write),
        .dma_writedata(dma_writedata), .dma_byteenable(dma_byteenable),
        .dma_readdata(dma_readdata), .dma_readdatavalid(dma_readdatavalid),
        .dma_waitrequest(dma_waitrequest), .dma_writeresponsevalid(dma_writeresponsevalid),
        .irq(irq));

    // ------------------------------------------------------------ DDR / interconnect model
    reg [63:0] mem [0:MEMW-1];
    integer    wait_pct = 30;                 // probability (%) of waitrequest per cycle
    integer    max_lat  = 6;
    integer    rd_count = 0, wr_count = 0;

    // read pipeline: each accepted read is returned after a random number of cycles, strictly in order
    reg [63:0] rq_data [0:63];
    integer    rq_ready [0:63];
    integer    rq_wp = 0, rq_rp = 0, cyc = 0;
    reg        rv; reg [63:0] rd;
    reg        wrv;
    reg        wait_r;

    assign dma_waitrequest        = wait_r;
    assign dma_readdatavalid      = rv;
    assign dma_readdata           = rd;
    assign dma_writeresponsevalid = wrv;

    always @(negedge clk) wait_r <= (($urandom % 100) < wait_pct);

    always @(posedge clk) begin
        cyc <= cyc + 1;
        rv  <= 1'b0;
        wrv <= 1'b0;
        if (dma_read && !wait_r) begin
            if (dma_address[2:0] != 0 || dma_address[31:3] >= MEMW) begin
                $display("FAIL: bad read address %h", dma_address); errors = errors + 1;
            end
            // blocking: the return check below runs in the same timestep and must see this entry
            rq_data[rq_wp % 64]  = mem[dma_address[31:3]];
            rq_ready[rq_wp % 64] = cyc + 1 + ($urandom % (max_lat + 1));
            rq_wp = rq_wp + 1;
            rd_count = rd_count + 1;
        end
        if (rq_rp != rq_wp && rq_ready[rq_rp % 64] <= cyc) begin
            rv <= 1'b1;
            rd <= rq_data[rq_rp % 64];
            rq_rp = rq_rp + 1;
        end
        if (dma_write && !wait_r) begin
            if (dma_address[2:0] != 0 || dma_address[31:3] >= MEMW) begin
                $display("FAIL: bad write address %h", dma_address); errors = errors + 1;
            end else mem[dma_address[31:3]] <= dma_writedata;
            wrv <= 1'b1;
            wr_count = wr_count + 1;
        end
    end

    // ------------------------------------------------------------ CSR access
    task csr_wr(input [2:0] a, input [31:0] d);
        begin
            @(negedge clk); csr_address = a; csr_writedata = d; csr_write = 1;
            @(negedge clk); csr_write = 0;
        end
    endtask
    task csr_rd(input [2:0] a, output [31:0] d);
        begin
            @(negedge clk); csr_address = a; csr_read = 1;
            @(negedge clk); csr_read = 0;
            #1 d = csr_readdata;
        end
    endtask

    // ------------------------------------------------------------ helpers
    integer errors = 0, tests = 0;

    function integer rs8(input integer dummy); begin rs8 = ($urandom % 256) - 128; end endfunction

    function integer qref(input integer acc, input integer bias, input integer sh, input integer relu);
        integer v;
        begin
            v = acc + bias;
            if (sh > 0) v = (v + (1 << (sh - 1))) >>> sh;
            if (relu != 0 && v < 0) v = 0;
            if (v > 127) v = 127;
            if (v < -128) v = -128;
            qref = v;
        end
    endfunction

    // per-tile model data (up to 24 tiles per run)
    localparam MAXT = 24;
    integer tA [0:MAXT-1][0:7][0:31];
    integer tW [0:MAXT-1][0:31][0:7];
    integer tB [0:MAXT-1][0:7];
    integer tK [0:MAXT-1];
    integer tS [0:MAXT-1];
    integer tR [0:MAXT-1];

    localparam DESC0 = 32'h0000_0000;          // descriptor table
    localparam DATA0 = 32'h0000_4000;          // operand area
    localparam OUT0  = 32'h0008_0000;          // result area

    // lay a tile out in memory and write its descriptor
    task place_tile(input integer n, input integer a_addr, input integer w_addr, input integer o_addr);
        integer r, k, c, i;
        reg [63:0] wd;
        reg [63:0] d [0:7];
        begin
            for (k = 0; k < tK[n]; k = k + 1) begin
                wd = 0; for (r = 0; r < 8; r = r + 1) wd[r*8 +: 8] = tA[n][r][k];
                mem[(a_addr >> 3) + k] = wd;
                wd = 0; for (c = 0; c < 8; c = c + 1) wd[c*8 +: 8] = tW[n][k][c];
                mem[(w_addr >> 3) + k] = wd;
            end
            for (i = 0; i < 8; i = i + 1) d[i] = 0;
            d[0] = {w_addr[31:0], a_addr[31:0]};
            d[1] = {15'd0, tR[n][0], 3'd0, tS[n][4:0], tK[n][7:0], o_addr[31:0]};
            for (i = 0; i < 4; i = i + 1) begin
                d[2+i][31:0]  = tB[n][2*i];
                d[2+i][63:32] = tB[n][2*i + 1];
            end
            for (i = 0; i < 8; i = i + 1) mem[(DESC0 >> 3) + n*8 + i] = d[i];
        end
    endtask

    task run_dma(input integer ntiles, input integer base, output integer ok);
        reg [31:0] st;
        integer w;
        begin
            csr_wr(3'd1, base);
            csr_wr(3'd2, ntiles);
            csr_wr(3'd3, 32'h6);                    // clear sticky flags
            csr_wr(3'd0, 32'h3);                    // start + irq enable
            w = 0; st = 0;
            while (!irq && w < 400000) begin @(negedge clk); w = w + 1; end
            csr_rd(3'd3, st);
            ok = (w < 400000);
            if (!ok) begin $display("FAIL: DMA run timed out (STATUS=%h)", st); errors = errors + 1; end
        end
    endtask

    task check_outputs(input integer ntiles, input [255:0] name);
        integer n, r, c, k, acc, exp, got;
        begin
            for (n = 0; n < ntiles; n = n + 1)
                for (r = 0; r < 8; r = r + 1)
                    for (c = 0; c < 8; c = c + 1) begin
                        acc = 0;
                        for (k = 0; k < tK[n]; k = k + 1) acc = acc + tA[n][r][k] * tW[n][k][c];
                        exp = qref(acc, tB[n][c], tS[n], tR[n]);
                        got = $signed(mem[(OUT0 >> 3) + n*8 + r][c*8 +: 8]);
                        if (got !== exp) begin
                            if (errors < 20) $display("FAIL [%0s] tile %0d out[%0d][%0d]=%0d expected %0d",
                                                      name, n, r, c, got, exp);
                            errors = errors + 1;
                        end
                    end
            tests = tests + 1;
        end
    endtask

    task random_run(input integer ntiles, input integer fixedk, input [255:0] name);
        integer n, r, k, c, ok;
        reg [31:0] v;
        begin
            for (n = 0; n < ntiles; n = n + 1) begin
                tK[n] = (fixedk > 0) ? fixedk : 1 + ($urandom % 32);
                tS[n] = $urandom % 14;
                tR[n] = $urandom % 2;
                for (r = 0; r < 8; r = r + 1) for (k = 0; k < tK[n]; k = k + 1) tA[n][r][k] = rs8(0);
                for (k = 0; k < tK[n]; k = k + 1) for (c = 0; c < 8; c = c + 1) tW[n][k][c] = rs8(0);
                for (c = 0; c < 8; c = c + 1) tB[n][c] = ($urandom % 20001) - 10000;
                place_tile(n, DATA0 + n*1024, DATA0 + n*1024 + 512, OUT0 + n*64);
            end
            for (n = 0; n < ntiles*8; n = n + 1) mem[(OUT0 >> 3) + n] = 64'hDEAD_BEEF_DEAD_BEEF;
            run_dma(ntiles, DESC0, ok);
            if (ok) begin
                csr_rd(3'd4, v);
                if (v !== ntiles) begin $display("FAIL [%0s] TILES_DONE=%0d expected %0d", name, v, ntiles); errors = errors + 1; end
                csr_rd(3'd3, v);
                if (v[2] || !v[1] || v[0]) begin $display("FAIL [%0s] STATUS=%h", name, v); errors = errors + 1; end
                check_outputs(ntiles, name);
            end
        end
    endtask

    // ------------------------------------------------------------ main
    integer i, ok, cyc_run;
    reg [31:0] v;
    initial begin
        $dumpfile("sim/tb_soc.vcd");
        $dumpvars(0, tb_soc);
        for (i = 0; i < MEMW; i = i + 1) mem[i] = 0;
        repeat (5) @(negedge clk);
        rst = 0;
        repeat (3) @(negedge clk);

        csr_rd(3'd7, v);
        if (v !== 32'h4E505532) begin $display("FAIL: ID = %h", v); errors = errors + 1; end

        // (a) random tiles with random memory timing
        random_run(1, 0, "single");
        random_run(8, 0, "random8");
        random_run(MAXT, 0, "random24");

        // (b) heavy memory back-pressure and long latency
        wait_pct = 70; max_lat = 20;
        random_run(12, 0, "slowmem");
        wait_pct = 0; max_lat = 0;
        random_run(12, 32, "fastmem_k32");
        csr_rd(3'd6, v);
        $display("INFO: 12 tiles K=32 with ideal memory: %0d cycles total (%0d cycles/tile; core-only tile = 56)", v, v/12);
        wait_pct = 30; max_lat = 6;

        // (c) chained layer: C(16x16) = A(16x32) x B(32x16) as four tiles
        begin : layer
            integer LA [0:15][0:31]; integer LW [0:31][0:15]; integer LB [0:15];
            integer mt, nt, n, r, k, c, acc, exp, got;
            for (r = 0; r < 16; r = r + 1) for (k = 0; k < 32; k = k + 1) LA[r][k] = rs8(0);
            for (k = 0; k < 32; k = k + 1) for (c = 0; c < 16; c = c + 1) LW[k][c] = rs8(0);
            for (c = 0; c < 16; c = c + 1) LB[c] = ($urandom % 20001) - 10000;
            n = 0;
            for (mt = 0; mt < 2; mt = mt + 1)
                for (nt = 0; nt < 2; nt = nt + 1) begin
                    tK[n] = 32; tS[n] = 10; tR[n] = 1;
                    for (r = 0; r < 8; r = r + 1) for (k = 0; k < 32; k = k + 1) tA[n][r][k] = LA[mt*8 + r][k];
                    for (k = 0; k < 32; k = k + 1) for (c = 0; c < 8; c = c + 1) tW[n][k][c] = LW[k][nt*8 + c];
                    for (c = 0; c < 8; c = c + 1) tB[n][c] = LB[nt*8 + c];
                    place_tile(n, DATA0 + n*1024, DATA0 + n*1024 + 512, OUT0 + n*64);
                    n = n + 1;
                end
            run_dma(4, DESC0, ok);
            for (mt = 0; mt < 2; mt = mt + 1)
                for (nt = 0; nt < 2; nt = nt + 1)
                    for (r = 0; r < 8; r = r + 1)
                        for (c = 0; c < 8; c = c + 1) begin
                            acc = 0;
                            for (k = 0; k < 32; k = k + 1) acc = acc + LA[mt*8 + r][k] * LW[k][nt*8 + c];
                            exp = qref(acc, LB[nt*8 + c], 10, 1);
                            got = $signed(mem[(OUT0 >> 3) + (mt*2 + nt)*8 + r][c*8 +: 8]);
                            if (got !== exp) begin
                                if (errors < 20) $display("FAIL [layer] C[%0d][%0d]=%0d expected %0d", mt*8+r, nt*8+c, got, exp);
                                errors = errors + 1;
                            end
                        end
            tests = tests + 1;
        end

        // (d) bad descriptor (K = 0) in the middle: error flagged, earlier tiles still correct, run terminates
        tK[0] = 4; tS[0] = 3; tR[0] = 0;
        for (i = 0; i < 8; i = i + 1) begin : g0 integer k; for (k = 0; k < 4; k = k + 1) tA[0][i][k] = rs8(0); end
        for (i = 0; i < 4; i = i + 1) begin : g1 integer c; for (c = 0; c < 8; c = c + 1) tW[0][i][c] = rs8(0); end
        for (i = 0; i < 8; i = i + 1) tB[0][i] = 0;
        place_tile(0, DATA0, DATA0 + 512, OUT0);
        tK[1] = 0; tS[1] = 0; tR[1] = 0;
        for (i = 0; i < 8; i = i + 1) tB[1][i] = 0;
        place_tile(1, DATA0, DATA0 + 512, OUT0 + 64);
        run_dma(2, DESC0, ok);
        csr_rd(3'd3, v);
        if (!v[2] || v[0]) begin $display("FAIL: bad descriptor not flagged (STATUS=%h)", v); errors = errors + 1; end
        tK[1] = 4;                                 // for check only tile 0
        check_outputs(1, "baddesc");

        // (e) recovery after the error
        random_run(5, 0, "recovery");

        // (f) zero-length run completes immediately
        csr_wr(3'd2, 0); csr_wr(3'd3, 32'h6); csr_wr(3'd0, 32'h3);
        repeat (20) @(negedge clk);
        csr_rd(3'd3, v);
        if (!v[1] || v[0]) begin $display("FAIL: zero-length run STATUS=%h", v); errors = errors + 1; end

        $display("INFO: memory traffic: %0d reads, %0d writes", rd_count, wr_count);
        $display("----------------------------------------");
        if (errors == 0) $display("PASS: SoC DMA test, %0d checks, 0 errors", tests);
        else             $display("FAIL: %0d errors in %0d checks", errors, tests);
        $display("----------------------------------------");
        $finish;
    end

    initial begin #800_000_000; $display("FAIL: global timeout"); $finish; end
endmodule

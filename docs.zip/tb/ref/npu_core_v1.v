// BASELINE (single-buffered) NPU core, kept only as a benchmark reference for tb_overlap.v.
// Load -> compute -> output run strictly one after another; the stream is blocked while computing.
module npu_core_v1 #(
    parameter N    = 8,
    parameter KMAX = 32,
    parameter DW   = 8,
    parameter AW   = 32
) (
    input  wire              clk,
    input  wire              rst,
    input  wire              cfg_relu,
    input  wire [4:0]        cfg_shift,
    input  wire [7:0]        cfg_klen,
    input  wire [N*AW-1:0]   cfg_bias,
    input  wire [N*DW-1:0]   s_tdata,
    input  wire              s_tvalid,
    output wire              s_tready,
    input  wire              s_tlast,
    output reg  [N*DW-1:0]   m_tdata,
    output reg               m_tvalid,
    input  wire              m_tready,
    output reg               m_tlast,
    output wire              busy,
    output reg               done_pulse,
    output reg               err_pulse,
    output reg  [31:0]       perf_cycles
);
    localparam S_LOAD = 2'd0, S_CLEAR = 2'd1, S_RUN = 2'd2, S_OUT = 2'd3;

    reg [1:0]       state;
    reg [8:0]       idx, cnt;
    reg [7:0]       klen_q;
    reg [4:0]       row;
    reg             pe_clear;
    reg [31:0]      perf_tmp;
    reg [N*DW-1:0]  a_buf [0:KMAX-1];
    reg [N*DW-1:0]  w_buf [0:KMAX-1];

    assign s_tready = (state == S_LOAD);
    assign busy     = (state != S_LOAD) || (idx != 0);

    wire        bad_k    = (cfg_klen == 0) || (cfg_klen > KMAX);
    wire [8:0]  last_idx = {cfg_klen, 1'b0} - 9'd1;
    wire [8:0]  run_last = klen_q + (2*N - 3);

    reg [N*DW-1:0] a_left, b_top;
    integer r, c, kk;
    always @* begin
        a_left = {N*DW{1'b0}};
        b_top  = {N*DW{1'b0}};
        if (state == S_RUN) begin
            for (r = 0; r < N; r = r + 1) begin
                kk = cnt - r;
                if (kk >= 0 && kk < klen_q) a_left[r*DW +: DW] = a_buf[kk][r*DW +: DW];
            end
            for (c = 0; c < N; c = c + 1) begin
                kk = cnt - c;
                if (kk >= 0 && kk < klen_q) b_top[c*DW +: DW] = w_buf[kk][c*DW +: DW];
            end
        end
    end

    wire [N*N*AW-1:0] acc_flat;
    systolic_array #(.N(N), .DW(DW), .AW(AW)) u_array (
        .clk(clk), .rst(rst), .clear(pe_clear),
        .a_left_flat(a_left), .b_top_flat(b_top), .acc_flat(acc_flat));

    function signed [DW-1:0] requant;
        input signed [AW-1:0] acc;
        input signed [AW-1:0] bias;
        input         [4:0]   sh;
        input                 relu;
        reg signed [AW+1:0] v;
        reg signed [AW+1:0] rnd;
        begin
            v = acc; v = v + bias;
            if (sh != 0) begin rnd = 1; rnd = rnd <<< (sh - 1); v = (v + rnd) >>> sh; end
            if (relu && v < 0) v = 0;
            if (v > 127)       requant = 8'sd127;
            else if (v < -128) requant = -8'sd128;
            else               requant = v[DW-1:0];
        end
    endfunction

    reg [N*DW-1:0] beat_c;
    integer j;
    always @* begin
        beat_c = {N*DW{1'b0}};
        for (j = 0; j < N; j = j + 1)
            beat_c[j*DW +: DW] = requant(acc_flat[(row*N + j)*AW +: AW],
                                         cfg_bias[j*AW +: AW], cfg_shift, cfg_relu);
    end

    always @(posedge clk) begin
        done_pulse <= 1'b0;
        err_pulse  <= 1'b0;
        if (rst) begin
            state <= S_LOAD; idx <= 0; cnt <= 0; row <= 0; klen_q <= 0; pe_clear <= 1'b0;
            m_tvalid <= 1'b0; m_tlast <= 1'b0; m_tdata <= 0; perf_tmp <= 0; perf_cycles <= 0;
        end else begin
            if (state != S_LOAD) perf_tmp <= perf_tmp + 1'b1;
            case (state)
                S_LOAD: if (s_tvalid) begin
                    if (bad_k) begin
                        if (s_tlast) begin err_pulse <= 1'b1; idx <= 0; end
                    end else begin
                        if (idx < cfg_klen) a_buf[idx]            <= s_tdata;
                        else                w_buf[idx - cfg_klen] <= s_tdata;
                        if (idx == last_idx) begin
                            if (!s_tlast) err_pulse <= 1'b1;
                            klen_q <= cfg_klen; idx <= 0; pe_clear <= 1'b1; perf_tmp <= 32'd1; state <= S_CLEAR;
                        end else if (s_tlast) begin err_pulse <= 1'b1; idx <= 0; end
                        else idx <= idx + 1'b1;
                    end
                end
                S_CLEAR: begin pe_clear <= 1'b0; cnt <= 0; state <= S_RUN; end
                S_RUN: begin
                    if (cnt == run_last) begin row <= 0; state <= S_OUT; end
                    else cnt <= cnt + 1'b1;
                end
                S_OUT: begin
                    if (m_tvalid && m_tready) m_tvalid <= 1'b0;
                    if (!m_tvalid || m_tready) begin
                        if (row != N) begin
                            m_tdata <= beat_c; m_tlast <= (row == N - 1); m_tvalid <= 1'b1; row <= row + 1'b1;
                        end else begin
                            perf_cycles <= perf_tmp; done_pulse <= 1'b1; state <= S_LOAD;
                        end
                    end
                end
            endcase
        end
    end
endmodule

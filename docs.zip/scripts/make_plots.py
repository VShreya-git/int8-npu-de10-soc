#!/usr/bin/env python3
"""Builds the evidence figures in docs/ from the simulation outputs in sim/ (run `make plots`).

  01_pipeline_timeline.png : per-tile LOAD / COMPUTE / OUTPUT occupancy from the VCD, single vs double buffered
  02_waveform.png          : digital waveform of the double-buffered core (signals straight from the VCD)
  03_k_sweep.png           : cycles per tile vs K for both cores (from the testbench output)
  04_correctness.png       : RTL output vs C reference for every output byte of 64 tiles
  05_dma_activity.png      : cumulative DDR transfers and finished tiles during a 64-tile DMA run
"""
import bisect
import os
import re
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIM, DOCS = os.path.join(ROOT, "sim"), os.path.join(ROOT, "docs")
os.makedirs(DOCS, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 130, "savefig.bbox": "tight"})
C_SINGLE, C_DOUBLE, C_REF = "#c0504d", "#2f6db5", "#555555"
TILE_COLORS = ["#2f6db5", "#e08a1e", "#3a9d5d", "#9b59b6", "#c0504d", "#17a2b8"]


# ----------------------------------------------------------------------------- minimal VCD reader
class Vcd:
    def __init__(self, path):
        self.sig = {}            # full name -> list of (time, int) ; x/z -> -1
        ids, scope = {}, []
        self.unit_ps = 1.0
        with open(path) as f:
            text = f.read().split("\n")
        i = 0
        while i < len(text):
            ln = text[i].strip()
            i += 1
            if ln.startswith("$timescale"):
                m = re.search(r"(\d+)\s*(fs|ps|ns|us)", ln if "$end" in ln else ln + text[i])
                self.unit_ps = int(m.group(1)) * {"fs": 1e-3, "ps": 1, "ns": 1e3, "us": 1e6}[m.group(2)]
            elif ln.startswith("$scope"):
                scope.append(ln.split()[2])
            elif ln.startswith("$upscope"):
                scope.pop()
            elif ln.startswith("$var"):
                p = ln.split()
                name = ".".join(scope + [p[4]])
                ids.setdefault(p[3], []).append(name)
                self.sig.setdefault(name, [])
            elif ln.startswith("$enddefinitions"):
                break
        t = 0
        for ln in text[i:]:
            ln = ln.strip()
            if not ln:
                continue
            if ln[0] == "#":
                t = int(ln[1:])
            elif ln[0] in "01xzXZ":
                for n in ids.get(ln[1:], []):
                    self.sig[n].append((t, int(ln[0]) if ln[0] in "01" else -1))
            elif ln[0] == "b":
                v, ident = ln[1:].split()
                val = int(v, 2) if set(v) <= {"0", "1"} else -1
                for n in ids.get(ident, []):
                    self.sig[n].append((t, val))
        self._t = {n: [x[0] for x in v] for n, v in self.sig.items()}

    def at(self, name, t):
        """value just before time t (i.e. what a flop sees at an edge at t)"""
        tl = self._t[name]
        k = bisect.bisect_left(tl, t) - 1
        return self.sig[name][k][1] if k >= 0 else -1

    def rising_edges(self, name):
        prev, out = 0, []
        for t, v in self.sig[name]:
            if v == 1 and prev != 1:
                out.append(t)
            prev = v
        return out


def sample(v, names, edges):
    return {n: np.array([v.at(n, t) for t in edges]) for n in names}


def runs(mask):
    """contiguous True runs -> list of (start, length)"""
    out, i, n = [], 0, len(mask)
    while i < n:
        if mask[i]:
            j = i
            while j < n and mask[j]:
                j += 1
            out.append((i, j - i))
            i = j
        else:
            i += 1
    return out


# ----------------------------------------------------------------------------- figure 1: timeline
def fig_timeline():
    v = Vcd(os.path.join(SIM, "timeline.vcd"))
    edges = v.rising_edges("tb_overlap.clk")
    S = sample(v, ["tb_overlap.sel2", "tb_overlap.s_tvalid", "tb_overlap.s1_ready", "tb_overlap.s2_ready",
                   "tb_overlap.c1.state", "tb_overlap.c2.cs", "tb_overlap.c2.out_full",
                   "tb_overlap.rst"], edges)
    K = 32
    beats_per_tile = 2 * K

    def lanes(phase):
        win = (S["tb_overlap.sel2"] == phase) & (S["tb_overlap.rst"] == 0)
        idx = np.where(win)[0]
        if phase == 0:
            load = (S["tb_overlap.s_tvalid"] == 1) & (S["tb_overlap.s1_ready"] == 1)
            comp = np.isin(S["tb_overlap.c1.state"], [1, 2])
            outp = S["tb_overlap.c1.state"] == 3
        else:
            load = (S["tb_overlap.s_tvalid"] == 1) & (S["tb_overlap.s2_ready"] == 1)
            comp = S["tb_overlap.c2.cs"] > 0
            outp = S["tb_overlap.c2.out_full"] == 1
        first = idx[np.argmax(load[idx])]
        idx = idx[idx >= first]
        load, comp, outp = load[idx], comp[idx], outp[idx]
        return load, comp, outp

    fig, axes = plt.subplots(2, 1, figsize=(11, 4.6), sharex=True)
    spans = []
    for ax, phase, title, col in ((axes[0], 0, "Single-buffered core: one stage at a time", C_SINGLE),
                                  (axes[1], 1, "Double-buffered core: load, compute and output overlap", C_DOUBLE)):
        load, comp, outp = lanes(phase)
        n = len(load)
        spans.append(n)
        # tile id per load beat / per compute run / per output run
        ids_load = np.cumsum(load) - 1
        for y, mask, kind in ((2, load, "load"), (1, comp, "comp"), (0, outp, "out")):
            if kind == "load":
                prev = None
                segs = []
                for c in range(n):
                    if mask[c]:
                        tid = int(ids_load[c] // beats_per_tile)
                        if prev is not None and prev[0] == tid and prev[2] == c - 1:
                            prev[2] = c
                            prev[3] += 1
                        else:
                            prev = [tid, c, c, 1]
                            segs.append(prev)
                for tid, c0, c1, _ in segs:
                    ax.broken_barh([(c0, c1 - c0 + 1)], (y - 0.35, 0.7),
                                   color=TILE_COLORS[tid % 6], edgecolor="white", linewidth=0.4)
            else:
                for tid, (s, ln) in enumerate(runs(mask)):
                    ax.broken_barh([(s, ln)], (y - 0.35, 0.7), color=TILE_COLORS[tid % 6],
                                   edgecolor="white", linewidth=0.4)
        ax.set_yticks([2, 1, 0])
        ax.set_yticklabels(["LOAD\n(stream in)", "COMPUTE\n(array)", "OUTPUT\n(stream out)"])
        ax.set_title(f"{title}   -   {n} cycles for 4 tiles (K=32)", loc="left", color=col, fontweight="bold")
        ax.set_ylim(-0.7, 2.7)
        ax.grid(axis="x", alpha=0.25)
    axes[1].set_xlabel("clock cycles (from first input beat)")
    axes[1].set_xlim(0, max(spans) + 8)
    handles = [plt.Rectangle((0, 0), 1, 1, color=TILE_COLORS[i]) for i in range(4)]
    fig.legend(handles, [f"tile {i}" for i in range(4)], ncol=4, loc="upper right", frameon=False,
               bbox_to_anchor=(0.98, 1.02))
    fig.suptitle("Pipeline occupancy extracted from the simulation waveform (VCD)", x=0.01, ha="left",
                 fontsize=12, fontweight="bold", y=1.04)
    fig.savefig(os.path.join(DOCS, "01_pipeline_timeline.png"))
    plt.close(fig)


# ----------------------------------------------------------------------------- figure 2: waveform
def fig_waveform():
    v = Vcd(os.path.join(SIM, "wave.vcd"))
    edges = v.rising_edges("tb_overlap.clk")
    names = {"tvalid": "tb_overlap.s_tvalid", "tready": "tb_overlap.s2_ready", "tlast": "tb_overlap.s_tlast",
             "full": "tb_overlap.c2.full", "cs": "tb_overlap.c2.cs", "outfull": "tb_overlap.c2.out_full",
             "mvalid": "tb_overlap.m2_valid", "mlast": "tb_overlap.m2_last",
             "sel2": "tb_overlap.sel2", "rst": "tb_overlap.rst"}
    S = sample(v, list(names.values()), edges)
    win = np.where((S[names["sel2"]] == 1) & (S[names["rst"]] == 0))[0]
    first = win[np.argmax(S[names["tvalid"]][win] == 1)]
    last = win[-1]
    sl = slice(first - 2, min(last, first + 78))
    x = np.arange(sl.stop - sl.start)
    state_names = {0: "IDLE", 1: "CLEAR", 2: "RUN", 3: "CAPW", 4: "CAP"}
    rows = [("s_tvalid", "tvalid", "bit"), ("s_tready", "tready", "bit"), ("s_tlast", "tlast", "bit"),
            ("input bank full [1:0]", "full", "bus2"), ("compute state", "cs", "state"),
            ("output buffer full", "outfull", "bit"), ("m_tvalid", "mvalid", "bit"),
            ("m_tlast (with tvalid)", "mlast", "bit")]
    fig, axes = plt.subplots(len(rows), 1, figsize=(11, 6.2), sharex=True)
    for ax, (label, key, kind) in zip(axes, rows):
        y = S[names[key]][sl]
        if key == "mlast":                               # tlast is only meaningful while tvalid is high
            y = y * (S[names["mvalid"]][sl] == 1)
        if kind == "bit":
            ax.step(x, np.where(y < 0, 0, y), where="post", color=C_DOUBLE, linewidth=1.6)
            ax.set_ylim(-0.2, 1.3)
            ax.set_yticks([0, 1])
        else:
            ax.set_ylim(0, 1)
            ax.set_yticks([])
            start = 0
            for i in range(1, len(y) + 1):
                if i == len(y) or y[i] != y[start]:
                    txt = state_names.get(int(y[start]), "?") if kind == "state" else format(int(y[start]) & 3, "02b")
                    shade = "#dfe9f6" if (kind == "bus2" and y[start] != 0) or (kind == "state" and y[start] != 0) else "#f2f2f2"
                    ax.axvspan(start, i, ymin=0.1, ymax=0.9, color=shade, ec="#9aa7b8", lw=0.6)
                    if i - start >= 2:
                        ax.text((start + i) / 2, 0.5, txt, ha="center", va="center", fontsize=8)
                    start = i
        ax.set_ylabel(label, rotation=0, ha="right", va="center", fontsize=9)
        ax.grid(axis="x", alpha=0.2)
    axes[-1].set_xlabel("clock cycles")
    fig.suptitle("Simulated waveform, double-buffered core, 3 back-to-back tiles (K=4): the next tile loads "
                 "while the previous one computes", x=0.01, ha="left", fontsize=11, fontweight="bold", y=0.995)
    fig.savefig(os.path.join(DOCS, "02_waveform.png"))
    plt.close(fig)


# ----------------------------------------------------------------------------- figure 3: K sweep
def fig_sweep():
    ks, single, double = [], [], []
    for ln in open(os.path.join(SIM, "sweep.txt")):
        k = int(re.match(r"K=(\d+)", ln).group(1))
        s = re.search(r"single-buffered core : \d+ cycles\s+\((\d+) cycles/tile", ln)
        d = re.search(r"double-buffered core : \d+ cycles\s+\((\d+) cycles/tile", ln)
        ks.append(k)
        single.append(int(s.group(1)))
        double.append(int(d.group(1)))
    ks, single, double = map(np.array, (ks, single, double))
    fig, (a, b) = plt.subplots(1, 2, figsize=(11, 4))
    a.plot(ks, single, "o-", color=C_SINGLE, label="single-buffered")
    a.plot(ks, double, "o-", color=C_DOUBLE, label="double-buffered")
    a.plot(ks, 2 * ks, "--", color=C_REF, label="input-stream limit (2K beats)")
    a.set_xlabel("K (inner dimension)")
    a.set_ylabel("cycles per tile (16 back-to-back tiles)")
    a.set_title("Throughput of an 8x8 tile", loc="left", fontweight="bold")
    a.legend(frameon=False)
    a.grid(alpha=0.25)
    sp = single / double
    bars = b.bar([str(k) for k in ks], sp, color=C_DOUBLE)
    for r, s in zip(bars, sp):
        b.text(r.get_x() + r.get_width() / 2, s + 0.02, f"{s:.2f}x", ha="center", fontsize=9)
    b.axhline(1, color=C_REF, lw=0.8)
    b.set_xlabel("K")
    b.set_ylabel("speedup of double buffering")
    b.set_title("Overlap pays off as compute grows", loc="left", fontweight="bold")
    b.set_ylim(0, max(sp) * 1.18)
    fig.savefig(os.path.join(DOCS, "03_k_sweep.png"))
    plt.close(fig)


# ----------------------------------------------------------------------------- figure 4: correctness
def read_bytes(path):
    out = []
    for ln in open(path):
        w = int(ln.strip(), 16)
        out.extend(((w >> (8 * c)) & 0xFF) for c in range(8))
    a = np.array(out, dtype=np.int16)
    return np.where(a > 127, a - 256, a)


def fig_correctness():
    ref, rtl = read_bytes(os.path.join(SIM, "sw_exp.hex")), read_bytes(os.path.join(SIM, "sw_act.hex"))
    assert len(ref) == len(rtl)
    bad = int(np.sum(ref != rtl))
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.9), gridspec_kw={"width_ratios": [1.1, 1.2, 0.7]})
    ax = axes[0]
    rng = np.random.default_rng(0)
    ax.scatter(ref + rng.normal(0, .25, len(ref)), rtl + rng.normal(0, .25, len(rtl)), s=5, alpha=0.35,
               color=C_DOUBLE, linewidths=0)
    ax.plot([-128, 127], [-128, 127], color=C_REF, lw=0.8, ls="--")
    ax.set_xlabel("C reference model output (int8)")
    ax.set_ylabel("RTL output (int8)")
    ax.set_title(f"{len(ref)} output bytes, {len(ref)//64} tiles", loc="left", fontweight="bold")
    ax.set_aspect("equal")
    ax = axes[1]
    ax.hist(rtl, bins=np.arange(-128.5, 128.5, 1), color=C_DOUBLE)
    ax.set_yscale("log")
    ax.set_xlabel("output value (int8)")
    ax.set_ylabel("count per value (log)")
    ax.set_title("Value range exercised", loc="left", fontweight="bold")
    for val, ha, dx, f in ((-128, "left", 6, 1.25), (0, "left", 8, 1.25), (127, "right", -6, 0.18)):
        cnt = int(np.sum(rtl == val))
        ax.text(val + dx, cnt * f, f"{cnt} bytes = {val}", fontsize=8, ha=ha, va="bottom")
    ax.set_ylim(0.8, 5000)
    ax = axes[2]
    ax.bar(["mismatching", "matching"], [bad, len(ref) - bad], color=[C_SINGLE, "#3a9d5d"])
    ax.set_title("RTL vs C model", loc="left", fontweight="bold")
    ax.set_ylabel("output bytes")
    for i, val in enumerate([bad, len(ref) - bad]):
        ax.text(i, val + len(ref) * 0.01, str(val), ha="center")
    ax.set_ylim(0, len(ref) * 1.12)
    fig.suptitle("Bit-exact check: DDR image built by the C driver, processed by the DMA + NPU RTL",
                 x=0.01, ha="left", fontsize=11, fontweight="bold", y=1.03)
    fig.savefig(os.path.join(DOCS, "04_correctness.png"))
    plt.close(fig)
    return bad, len(ref)


# ----------------------------------------------------------------------------- figure 5: DMA activity
def fig_dma():
    v = Vcd(os.path.join(SIM, "dma.vcd"))
    edges = v.rising_edges("tb_swvec.clk")
    S = sample(v, ["tb_swvec.dma_read", "tb_swvec.dma_write", "tb_swvec.dma_waitrequest",
                   "tb_swvec.dut.u_dma.tiles_done", "tb_swvec.dut.u_dma.busy"], edges)
    busy = np.where(S["tb_swvec.dut.u_dma.busy"] == 1)[0]
    s, e = busy[0], busy[-1]
    rd = ((S["tb_swvec.dma_read"] == 1) & (S["tb_swvec.dma_waitrequest"] == 0))[s:e + 1]
    wr = ((S["tb_swvec.dma_write"] == 1) & (S["tb_swvec.dma_waitrequest"] == 0))[s:e + 1]
    td = np.maximum(S["tb_swvec.dut.u_dma.tiles_done"][s:e + 1], 0)
    x = np.arange(len(rd))
    ntiles = int(td.max())
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(x, np.cumsum(rd), color=C_DOUBLE, label="read beats accepted (descriptors + operands)")
    ax.plot(x, np.cumsum(wr), color="#e08a1e", label="write beats accepted (results)")
    ax.set_xlabel("clock cycles since DMA start")
    ax.set_ylabel("cumulative 64-bit transfers")
    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.step(x, td, where="post", color="#3a9d5d", label="tiles written back")
    ax2.set_ylabel("tiles finished")
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, loc="upper left")
    total = len(rd)
    ax.set_title(f"{ntiles} tiles in {total} cycles = {total/ntiles:.0f} cycles/tile "
                 f"(memory model injects 25% wait states)", loc="left", fontweight="bold")
    ax.grid(alpha=0.25)
    fig.savefig(os.path.join(DOCS, "05_dma_activity.png"))
    plt.close(fig)
    return ntiles, total


if __name__ == "__main__":
    fig_timeline()
    fig_waveform()
    fig_sweep()
    bad, n = fig_correctness()
    nt, cyc = fig_dma()
    print(f"figures written to {DOCS}")
    print(f"correctness: {bad} mismatches of {n} bytes; DMA run: {nt} tiles in {cyc} cycles")

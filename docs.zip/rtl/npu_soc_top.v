// SoC version of the NPU: CSR slave (Avalon-MM, lightweight bridge) + DMA master (Avalon-MM, 64-bit,
// to DDR through the HPS FPGA-to-HPS bridge) + 8x8 double-buffered core.
module npu_soc_top #(
    parameter USE_WRITE_RESPONSE = 1
) (
    input  wire         clk,
    input  wire         reset,

    // control slave
    input  wire [2:0]   csr_address,
    input  wire         csr_read,
    input  wire         csr_write,
    input  wire [31:0]  csr_writedata,
    output wire [31:0]  csr_readdata,
    output wire         csr_waitrequest,

    // DMA master
    output wire [31:0]  dma_address,
    output wire         dma_read,
    output wire         dma_write,
    output wire [63:0]  dma_writedata,
    output wire [7:0]   dma_byteenable,
    input  wire [63:0]  dma_readdata,
    input  wire         dma_readdatavalid,
    input  wire         dma_waitrequest,
    input  wire         dma_writeresponsevalid,

    output wire         irq
);
    wire         start, dma_busy, dma_done, dma_err, core_err, core_done;
    wire [31:0]  desc_base;
    wire [15:0]  desc_count, tiles_done;
    wire [31:0]  tile_cycles;

    wire [63:0]  s_tdata, m_tdata;
    wire         s_tvalid, s_tready, s_tlast, m_tvalid, m_tready, m_tlast;
    wire         cfg_relu;
    wire [4:0]   cfg_shift;
    wire [7:0]   cfg_klen;
    wire [255:0] cfg_bias;

    npu_csr u_csr (
        .clk(clk), .rst(reset),
        .avs_address(csr_address), .avs_read(csr_read), .avs_write(csr_write),
        .avs_writedata(csr_writedata), .avs_readdata(csr_readdata), .avs_waitrequest(csr_waitrequest),
        .irq(irq), .start(start), .desc_base(desc_base), .desc_count(desc_count),
        .dma_busy(dma_busy), .dma_done(dma_done), .dma_err(dma_err), .core_err(core_err),
        .tiles_done(tiles_done), .tile_cycles(tile_cycles));

    npu_dma #(.N(8), .KMAX(32), .USE_WRITE_RESPONSE(USE_WRITE_RESPONSE)) u_dma (
        .clk(clk), .rst(reset),
        .start(start), .desc_base(desc_base), .desc_count(desc_count),
        .busy(dma_busy), .done_pulse(dma_done), .err_pulse(dma_err), .tiles_done(tiles_done),
        .avm_address(dma_address), .avm_read(dma_read), .avm_write(dma_write),
        .avm_writedata(dma_writedata), .avm_byteenable(dma_byteenable),
        .avm_readdata(dma_readdata), .avm_readdatavalid(dma_readdatavalid),
        .avm_waitrequest(dma_waitrequest), .avm_writeresponsevalid(dma_writeresponsevalid),
        .s_tdata(s_tdata), .s_tvalid(s_tvalid), .s_tready(s_tready), .s_tlast(s_tlast),
        .cfg_relu(cfg_relu), .cfg_shift(cfg_shift), .cfg_klen(cfg_klen), .cfg_bias(cfg_bias),
        .m_tdata(m_tdata), .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tlast(m_tlast));

    npu_core #(.N(8), .KMAX(32), .DW(8), .AW(32)) u_core (
        .clk(clk), .rst(reset),
        .cfg_relu(cfg_relu), .cfg_shift(cfg_shift), .cfg_klen(cfg_klen), .cfg_bias(cfg_bias),
        .s_tdata(s_tdata), .s_tvalid(s_tvalid), .s_tready(s_tready), .s_tlast(s_tlast),
        .m_tdata(m_tdata), .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tlast(m_tlast),
        .busy(), .done_pulse(core_done), .err_pulse(core_err), .perf_cycles(tile_cycles));
endmodule

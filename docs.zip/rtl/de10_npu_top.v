// DE10-Standard board top for the NPU demo.
//   KEY[0] : reset (active low)
//   KEY[1] : run the built-in self-test (BIST drives the NPU over APB + AXI4-Stream)
//   LEDR[0]: running   LEDR[9]: PASS   LEDR[8]: FAIL
module de10_npu_top (
    input  wire        CLOCK_50,
    input  wire [3:0]  KEY,
    output wire [9:0]  LEDR
);
    reg [2:0] rst_sr = 3'b111;
    always @(posedge CLOCK_50) rst_sr <= {rst_sr[1:0], ~KEY[0]};
    wire rst = rst_sr[2];

    reg [1:0] key_sr = 2'b11;
    always @(posedge CLOCK_50) key_sr <= {key_sr[0], KEY[1]};
    wire start = (key_sr == 2'b10);

    wire        psel, penable, pwrite, pready, pslverr;
    wire [7:0]  paddr;
    wire [31:0] pwdata, prdata;
    wire [63:0] s_tdata, m_tdata;
    wire        s_tvalid, s_tready, s_tlast, m_tvalid, m_tready, m_tlast;
    wire        busy, pass, fail;

    npu_top #(.N(8), .KMAX(32)) u_npu (
        .clk(CLOCK_50), .rst(rst),
        .psel(psel), .penable(penable), .pwrite(pwrite), .paddr(paddr), .pwdata(pwdata),
        .prdata(prdata), .pready(pready), .pslverr(pslverr),
        .s_axis_tdata(s_tdata), .s_axis_tvalid(s_tvalid), .s_axis_tready(s_tready), .s_axis_tlast(s_tlast),
        .m_axis_tdata(m_tdata), .m_axis_tvalid(m_tvalid), .m_axis_tready(m_tready), .m_axis_tlast(m_tlast));

    npu_bist #(.N(8), .K(8)) u_bist (
        .clk(CLOCK_50), .rst(rst), .start(start),
        .psel(psel), .penable(penable), .pwrite(pwrite), .paddr(paddr), .pwdata(pwdata),
        .s_tdata(s_tdata), .s_tvalid(s_tvalid), .s_tready(s_tready), .s_tlast(s_tlast),
        .m_tdata(m_tdata), .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tlast(m_tlast),
        .busy(busy), .pass(pass), .fail(fail));

    assign LEDR = {pass, fail, 7'b0, busy};
endmodule

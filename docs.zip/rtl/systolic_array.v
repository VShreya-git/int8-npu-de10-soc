// NxN output-stationary systolic array.
// A streams left->right (one value per row per cycle), B streams top->bottom
// (one value per column per cycle). Inputs must already be skewed by the feeder.
module systolic_array #(
    parameter N  = 4,
    parameter DW = 8,
    parameter AW = 32
) (
    input  wire                  clk,
    input  wire                  rst,
    input  wire                  clear,
    input  wire [N*DW-1:0]       a_left_flat,   // row i   -> [i*DW +: DW]
    input  wire [N*DW-1:0]       b_top_flat,    // column j -> [j*DW +: DW]
    output wire [N*N*AW-1:0]     acc_flat       // C[i][j] -> [(i*N+j)*AW +: AW]
);
    // a_w[i*(N+1)+j] is the A value entering PE(i,j); index j=N is the right edge (unused).
    // b_w[i*N+j]     is the B value entering PE(i,j); index i=N is the bottom edge (unused).
    wire signed [DW-1:0] a_w [0:N*(N+1)-1];
    wire signed [DW-1:0] b_w [0:(N+1)*N-1];

    genvar i, j;
    generate
        for (i = 0; i < N; i = i + 1) begin : g_edge_a
            assign a_w[i*(N+1)] = a_left_flat[i*DW +: DW];
        end
        for (j = 0; j < N; j = j + 1) begin : g_edge_b
            assign b_w[j] = b_top_flat[j*DW +: DW];
        end

        for (i = 0; i < N; i = i + 1) begin : g_row
            for (j = 0; j < N; j = j + 1) begin : g_col
                wire signed [AW-1:0] acc_o;
                pe #(.DW(DW), .AW(AW)) u_pe (
                    .clk   (clk),
                    .rst   (rst),
                    .clear (clear),
                    .a_in  (a_w[i*(N+1)+j]),
                    .b_in  (b_w[i*N+j]),
                    .a_out (a_w[i*(N+1)+j+1]),
                    .b_out (b_w[(i+1)*N+j]),
                    .acc   (acc_o)
                );
                assign acc_flat[(i*N+j)*AW +: AW] = acc_o;
            end
        end
    endgenerate
endmodule

// APB3 slave: control/status registers for the NPU core. Zero wait states.
//
//  0x00 CTRL    [0] relu_en
//  0x04 SHIFT   [4:0] requantization right-shift
//  0x08 KLEN    [7:0] number of K steps for the next tile (1..KMAX), reset value 8
//  0x0C STATUS  [0] busy (RO)  [1] done (sticky, write 1 to clear)  [2] error (sticky, write 1 to clear)
//  0x10 + 4*c   BIAS[c]  signed 32-bit, one per output column
//  0x40 PERF    cycles of the last tile (last input beat -> last output beat)
module npu_apb #(
    parameter N  = 8,
    parameter AW = 32
) (
    input  wire              clk,
    input  wire              rst,

    input  wire              psel,
    input  wire              penable,
    input  wire              pwrite,
    input  wire [7:0]        paddr,
    input  wire [31:0]       pwdata,
    output reg  [31:0]       prdata,
    output wire              pready,
    output wire              pslverr,

    output wire              cfg_relu,
    output wire [4:0]        cfg_shift,
    output wire [7:0]        cfg_klen,
    output wire [N*AW-1:0]   cfg_bias,

    input  wire              busy,
    input  wire              done_set,
    input  wire              err_set,
    input  wire [31:0]       perf
);
    reg             relu_r;
    reg [4:0]       shift_r;
    reg [7:0]       klen_r;
    reg [N*AW-1:0]  bias_r;
    reg             done_r, err_r;

    assign cfg_relu  = relu_r;
    assign cfg_shift = shift_r;
    assign cfg_klen  = klen_r;
    assign cfg_bias  = bias_r;
    assign pready    = 1'b1;
    assign pslverr   = 1'b0;

    wire        wr       = psel && penable && pwrite;
    wire [7:0]  bidx     = (paddr - 8'h10) >> 2;
    wire        in_bias  = (paddr >= 8'h10) && (paddr < 8'h10 + 4*N);

    always @(posedge clk) begin
        if (rst) begin
            relu_r  <= 1'b0;
            shift_r <= 5'd0;
            klen_r  <= 8'd8;
            bias_r  <= {N*AW{1'b0}};
            done_r  <= 1'b0;
            err_r   <= 1'b0;
        end else begin
            if (wr) begin
                case (paddr)
                    8'h00: relu_r  <= pwdata[0];
                    8'h04: shift_r <= pwdata[4:0];
                    8'h08: klen_r  <= pwdata[7:0];
                    8'h0C: begin
                        if (pwdata[1]) done_r <= 1'b0;
                        if (pwdata[2]) err_r  <= 1'b0;
                    end
                    default: if (in_bias) bias_r[bidx*AW +: AW] <= pwdata;
                endcase
            end
            if (done_set) done_r <= 1'b1;     // a new event wins over a simultaneous clear
            if (err_set)  err_r  <= 1'b1;
        end
    end

    always @* begin
        prdata = 32'd0;
        case (paddr)
            8'h00: prdata = {31'd0, relu_r};
            8'h04: prdata = {27'd0, shift_r};
            8'h08: prdata = {24'd0, klen_r};
            8'h0C: prdata = {29'd0, err_r, done_r, busy};
            8'h40: prdata = perf;
            default: if (in_bias) prdata = bias_r[bidx*AW +: AW];
        endcase
    end
endmodule

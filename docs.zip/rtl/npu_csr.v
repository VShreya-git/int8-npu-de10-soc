// Avalon-MM slave: control/status registers for the SoC version (32-bit, word addressed, 0 wait states,
// 1-cycle read latency). Connected to the HPS lightweight HPS-to-FPGA bridge.
//
//  word  byte   name         description
//   0    0x00   CTRL         [0] start (write 1, self-clearing)  [1] irq_enable
//   1    0x04   DESC_BASE    physical address of the descriptor table
//   2    0x08   DESC_COUNT   number of descriptors (tiles)
//   3    0x0C   STATUS       [0] busy (RO)  [1] done (sticky, W1C)  [2] error (sticky, W1C)
//   4    0x10   TILES_DONE   tiles written back in the current/last run (RO)
//   5    0x14   TILE_CYCLES  compute cycles of the most recent tile (RO)
//   6    0x18   RUN_CYCLES   clock cycles from start to done of the last run (RO)
//   7    0x1C   ID           0x4E505532 ("NPU2") (RO)
module npu_csr (
    input  wire         clk,
    input  wire         rst,

    input  wire [2:0]   avs_address,
    input  wire         avs_read,
    input  wire         avs_write,
    input  wire [31:0]  avs_writedata,
    output reg  [31:0]  avs_readdata,
    output wire         avs_waitrequest,

    output reg          irq,

    output reg          start,
    output reg  [31:0]  desc_base,
    output reg  [15:0]  desc_count,
    input  wire         dma_busy,
    input  wire         dma_done,
    input  wire         dma_err,
    input  wire         core_err,
    input  wire [15:0]  tiles_done,
    input  wire [31:0]  tile_cycles
);
    reg        irq_en, done_r, err_r;
    reg [31:0] run_cycles, run_cnt;

    assign avs_waitrequest = 1'b0;

    always @(posedge clk) begin
        start <= 1'b0;
        if (rst) begin
            irq_en <= 1'b0; desc_base <= 0; desc_count <= 0;
            done_r <= 1'b0; err_r <= 1'b0; run_cycles <= 0; run_cnt <= 0;
        end else begin
            if (dma_busy) run_cnt <= run_cnt + 1'b1;
            if (avs_write) begin
                case (avs_address)
                    3'd0: begin
                        irq_en <= avs_writedata[1];
                        if (avs_writedata[0] && !dma_busy) begin
                            start   <= 1'b1;
                            run_cnt <= 0;
                        end
                    end
                    3'd1: desc_base  <= avs_writedata;
                    3'd2: desc_count <= avs_writedata[15:0];
                    3'd3: begin
                        if (avs_writedata[1]) done_r <= 1'b0;
                        if (avs_writedata[2]) err_r  <= 1'b0;
                    end
                    default: ;
                endcase
            end
            if (dma_done) begin done_r <= 1'b1; run_cycles <= run_cnt; end
            if (dma_err || core_err) err_r <= 1'b1;
        end
    end

    always @(posedge clk) begin
        // an error alone raises the interrupt only once the engine has drained, so software never
        // sees a busy engine with half-written results when the interrupt fires
        irq <= irq_en & (done_r | (err_r & ~dma_busy));
        case (avs_address)
            3'd0: avs_readdata <= {30'd0, irq_en, 1'b0};
            3'd1: avs_readdata <= desc_base;
            3'd2: avs_readdata <= {16'd0, desc_count};
            3'd3: avs_readdata <= {29'd0, err_r, done_r, dma_busy};
            3'd4: avs_readdata <= {16'd0, tiles_done};
            3'd5: avs_readdata <= tile_cycles;
            3'd6: avs_readdata <= run_cycles;
            3'd7: avs_readdata <= 32'h4E505532;
        endcase
    end
endmodule

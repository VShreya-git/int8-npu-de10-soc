// NPU top level: APB control port + AXI4-Stream in/out around npu_core.
module npu_top #(
    parameter N    = 8,
    parameter KMAX = 32
) (
    input  wire              clk,
    input  wire              rst,

    // APB3 slave
    input  wire              psel,
    input  wire              penable,
    input  wire              pwrite,
    input  wire [7:0]        paddr,
    input  wire [31:0]       pwdata,
    output wire [31:0]       prdata,
    output wire              pready,
    output wire              pslverr,

    // AXI4-Stream slave (A columns then W rows)
    input  wire [N*8-1:0]    s_axis_tdata,
    input  wire              s_axis_tvalid,
    output wire              s_axis_tready,
    input  wire              s_axis_tlast,

    // AXI4-Stream master (output rows)
    output wire [N*8-1:0]    m_axis_tdata,
    output wire              m_axis_tvalid,
    input  wire              m_axis_tready,
    output wire              m_axis_tlast
);
    localparam AW = 32;

    wire              cfg_relu;
    wire [4:0]        cfg_shift;
    wire [7:0]        cfg_klen;
    wire [N*AW-1:0]   cfg_bias;
    wire              busy, done_pulse, err_pulse;
    wire [31:0]       perf;

    npu_apb #(.N(N), .AW(AW)) u_apb (
        .clk(clk), .rst(rst),
        .psel(psel), .penable(penable), .pwrite(pwrite), .paddr(paddr), .pwdata(pwdata),
        .prdata(prdata), .pready(pready), .pslverr(pslverr),
        .cfg_relu(cfg_relu), .cfg_shift(cfg_shift), .cfg_klen(cfg_klen), .cfg_bias(cfg_bias),
        .busy(busy), .done_set(done_pulse), .err_set(err_pulse), .perf(perf));

    npu_core #(.N(N), .KMAX(KMAX), .DW(8), .AW(AW)) u_core (
        .clk(clk), .rst(rst),
        .cfg_relu(cfg_relu), .cfg_shift(cfg_shift), .cfg_klen(cfg_klen), .cfg_bias(cfg_bias),
        .s_tdata(s_axis_tdata), .s_tvalid(s_axis_tvalid), .s_tready(s_axis_tready), .s_tlast(s_axis_tlast),
        .m_tdata(m_axis_tdata), .m_tvalid(m_axis_tvalid), .m_tready(m_axis_tready), .m_tlast(m_axis_tlast),
        .busy(busy), .done_pulse(done_pulse), .err_pulse(err_pulse), .perf_cycles(perf));
endmodule

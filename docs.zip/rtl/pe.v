// Processing element: output-stationary MAC.
// Passes A to the right and B downward each cycle, accumulates a*b locally.
module pe #(
    parameter DW = 8,
    parameter AW = 32
) (
    input  wire                 clk,
    input  wire                 rst,
    input  wire                 clear,   // zero the accumulator (start of a new matmul)
    input  wire signed [DW-1:0] a_in,
    input  wire signed [DW-1:0] b_in,
    output reg  signed [DW-1:0] a_out,
    output reg  signed [DW-1:0] b_out,
    output reg  signed [AW-1:0] acc
);
    always @(posedge clk) begin
        if (rst || clear) begin
            a_out <= 0;
            b_out <= 0;
            acc   <= 0;
        end else begin
            a_out <= a_in;
            b_out <= b_in;
            acc   <= acc + a_in * b_in;
        end
    end
endmodule

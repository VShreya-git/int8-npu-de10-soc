// INT8 NPU compute core, double-buffered.
//
// One "tile" operation:   OUT = sat_int8( relu?( (A * W + bias) >> shift ) )
//   A : N x K  int8   (N = array size, K = 1..KMAX)
//   W : K x N  int8
//   bias : N x int32 (one per output column), shift : 0..31 (round-half-up), relu on/off
//
// Data path = AXI4-Stream, N bytes per beat.
//   Slave  : 2K beats. Beats 0..K-1   carry column k of A  (byte r = A[r][k]).
//                      Beats K..2K-1  carry row    k of W  (byte c = W[k][c]).  tlast on the final beat.
//   Master : N beats. Beat r carries output row r (byte c = OUT[r][c]).          tlast on the final beat.
//
// Pipeline (three stages that overlap across consecutive tiles):
//   LOAD    : stream -> one of two ping-pong input banks
//   COMPUTE : systolic array on the other bank, then requantize into the output buffer
//   OUTPUT  : output buffer -> stream
// cfg_klen / cfg_relu / cfg_shift / cfg_bias belong to the tile being loaded: they are sampled when the
// tile's last input beat is accepted (cfg_klen is also used during the packet to frame it), so they must be
// stable from the tile's first beat to its last. They may change freely afterwards, while earlier tiles
// are still computing or streaming out.
module npu_core #(
    parameter N    = 8,
    parameter KMAX = 32,
    parameter DW   = 8,
    parameter AW   = 32
) (
    input  wire              clk,
    input  wire              rst,

    input  wire              cfg_relu,
    input  wire [4:0]        cfg_shift,
    input  wire [7:0]        cfg_klen,
    input  wire [N*AW-1:0]   cfg_bias,

    input  wire [N*DW-1:0]   s_tdata,
    input  wire              s_tvalid,
    output wire              s_tready,
    input  wire              s_tlast,

    output reg  [N*DW-1:0]   m_tdata,
    output reg               m_tvalid,
    input  wire              m_tready,
    output reg               m_tlast,

    output wire              busy,
    output reg               done_pulse,    // one pulse per tile, when its last output beat is accepted
    output reg               err_pulse,
    output reg  [31:0]       perf_cycles    // compute cycles (clear + array + capture) of the last tile
);
    // ------------------------------------------------------------ storage
    reg [N*DW-1:0]  a_buf [0:2*KMAX-1];     // bank b occupies [b*KMAX +: KMAX]
    reg [N*DW-1:0]  w_buf [0:2*KMAX-1];
    reg [N*DW-1:0]  out_buf [0:N-1];
    reg [7:0]       klen_b [0:1];
    reg             relu_b [0:1];            // per-bank config, captured when the tile's last beat is accepted
    reg [4:0]       shift_b [0:1];
    reg [N*AW-1:0]  bias_b [0:1];

    // ------------------------------------------------------------ LOAD stage
    reg             wr_bank;
    reg [1:0]       full;
    reg [8:0]       idx;

    assign s_tready = !full[wr_bank];

    wire        bad_k    = (cfg_klen == 0) || (cfg_klen > KMAX);
    wire [8:0]  last_idx = {cfg_klen, 1'b0} - 9'd1;
    wire        s_fire   = s_tvalid && s_tready;

    // ------------------------------------------------------------ COMPUTE stage
    localparam C_IDLE = 3'd0, C_CLEAR = 3'd1, C_RUN = 3'd2, C_CAPW = 3'd3, C_CAP = 3'd4;

    reg [2:0]       cs;
    reg             cbank;
    reg [7:0]       klen_q;
    reg [8:0]       cnt;
    reg [3:0]       row;
    reg             pe_clear;
    reg [31:0]      perf_tmp;
    reg             relu_s;
    reg [4:0]       shift_s;
    reg [N*AW-1:0]  bias_s;

    wire [8:0]  run_last = klen_q + (2*N - 3);

    // skewed feeders
    reg [N*DW-1:0] a_left, b_top;
    integer r, c, kk;
    always @* begin
        a_left = {N*DW{1'b0}};
        b_top  = {N*DW{1'b0}};
        if (cs == C_RUN) begin
            for (r = 0; r < N; r = r + 1) begin
                kk = cnt - r;
                if (kk >= 0 && kk < klen_q)
                    a_left[r*DW +: DW] = a_buf[(cbank ? KMAX : 0) + kk][r*DW +: DW];
            end
            for (c = 0; c < N; c = c + 1) begin
                kk = cnt - c;
                if (kk >= 0 && kk < klen_q)
                    b_top[c*DW +: DW] = w_buf[(cbank ? KMAX : 0) + kk][c*DW +: DW];
            end
        end
    end

    wire [N*N*AW-1:0] acc_flat;
    systolic_array #(.N(N), .DW(DW), .AW(AW)) u_array (
        .clk(clk), .rst(rst), .clear(pe_clear),
        .a_left_flat(a_left), .b_top_flat(b_top), .acc_flat(acc_flat));

    // requantization: acc + bias, rounding right shift, optional ReLU, int8 saturation
    function signed [DW-1:0] requant;
        input signed [AW-1:0] acc;
        input signed [AW-1:0] bias;
        input         [4:0]   sh;
        input                 relu;
        reg signed [AW+1:0] v;
        reg signed [AW+1:0] rnd;
        begin
            v = acc;
            v = v + bias;
            if (sh != 0) begin
                rnd = 1;
                rnd = rnd <<< (sh - 1);
                v   = (v + rnd) >>> sh;
            end
            if (relu && v < 0) v = 0;
            if (v > 127)       requant = 8'sd127;
            else if (v < -128) requant = -8'sd128;
            else               requant = v[DW-1:0];
        end
    endfunction

    reg [N*DW-1:0] beat_c;
    integer j;
    always @* begin
        beat_c = {N*DW{1'b0}};
        for (j = 0; j < N; j = j + 1)
            beat_c[j*DW +: DW] = requant(acc_flat[(row*N + j)*AW +: AW],
                                         bias_s[j*AW +: AW], shift_s, relu_s);
    end

    // ------------------------------------------------------------ OUTPUT stage
    reg         out_full;
    reg [3:0]   orow;

    assign busy = (idx != 0) || (full != 2'b00) || (cs != C_IDLE) || out_full || m_tvalid;

    // ------------------------------------------------------------ sequential logic
    always @(posedge clk) begin
        done_pulse <= 1'b0;
        err_pulse  <= 1'b0;
        if (rst) begin
            wr_bank     <= 1'b0;
            full        <= 2'b00;
            idx         <= 0;
            cs          <= C_IDLE;
            cbank       <= 1'b0;
            cnt         <= 0;
            row         <= 0;
            klen_q      <= 0;
            pe_clear    <= 1'b0;
            perf_tmp    <= 0;
            perf_cycles <= 0;
            out_full    <= 1'b0;
            orow        <= 0;
            m_tvalid    <= 1'b0;
            m_tlast     <= 1'b0;
            m_tdata     <= 0;
        end else begin
            // ---------------- LOAD
            if (s_fire) begin
                if (bad_k) begin                           // invalid K: swallow packet, flag error
                    if (s_tlast) err_pulse <= 1'b1;
                    idx <= 0;
                end else begin
                    if (idx < cfg_klen) a_buf[(wr_bank ? KMAX : 0) + idx]            <= s_tdata;
                    else                w_buf[(wr_bank ? KMAX : 0) + idx - cfg_klen] <= s_tdata;
                    if (idx == last_idx) begin
                        if (!s_tlast) err_pulse <= 1'b1;   // packet longer than 2K
                        klen_b[wr_bank]  <= cfg_klen;
                        relu_b[wr_bank]  <= cfg_relu;
                        shift_b[wr_bank] <= cfg_shift;
                        bias_b[wr_bank]  <= cfg_bias;
                        full[wr_bank]   <= 1'b1;
                        wr_bank         <= ~wr_bank;
                        idx             <= 0;
                    end else if (s_tlast) begin            // packet shorter than 2K: abort
                        err_pulse <= 1'b1;
                        idx       <= 0;
                    end else idx <= idx + 1'b1;
                end
            end

            // ---------------- COMPUTE
            if (cs != C_IDLE) perf_tmp <= perf_tmp + 1'b1;
            case (cs)
                C_IDLE: if (full[cbank]) begin
                    klen_q   <= klen_b[cbank];
                    relu_s   <= relu_b[cbank];
                    shift_s  <= shift_b[cbank];
                    bias_s   <= bias_b[cbank];
                    pe_clear <= 1'b1;
                    perf_tmp <= 32'd1;
                    cs       <= C_CLEAR;
                end
                C_CLEAR: begin
                    pe_clear <= 1'b0;
                    cnt      <= 0;
                    cs       <= C_RUN;
                end
                C_RUN: begin
                    if (cnt == run_last) cs <= C_CAPW;
                    else cnt <= cnt + 1'b1;
                end
                C_CAPW: if (!out_full) begin
                    row <= 0;
                    cs  <= C_CAP;
                end
                C_CAP: begin
                    out_buf[row] <= beat_c;
                    if (row == N - 1) begin
                        out_full       <= 1'b1;
                        full[cbank]    <= 1'b0;            // input bank is free again
                        cbank          <= ~cbank;
                        perf_cycles    <= perf_tmp + 1'b1;
                        cs             <= C_IDLE;
                    end else row <= row + 1'b1;
                end
                default: cs <= C_IDLE;
            endcase

            // ---------------- OUTPUT
            if (out_full) begin
                if (m_tvalid && m_tready) m_tvalid <= 1'b0;
                if (!m_tvalid || m_tready) begin
                    if (orow != N) begin
                        m_tdata  <= out_buf[orow];
                        m_tlast  <= (orow == N - 1);
                        m_tvalid <= 1'b1;
                        orow     <= orow + 1'b1;
                    end else begin                          // last beat has been accepted
                        out_full   <= 1'b0;
                        orow       <= 0;
                        done_pulse <= 1'b1;
                    end
                end
            end
        end
    end
endmodule

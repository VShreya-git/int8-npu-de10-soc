// Built-in self-test for the board: acts as APB master + AXI4-Stream source/sink.
// Programs the NPU (ReLU on, shift 4, K=8, per-column bias), streams a fixed tile in,
// receives the result with output backpressure, and compares with a compile-time reference.
module npu_bist #(
    parameter N = 8,
    parameter K = 8
) (
    input  wire              clk,
    input  wire              rst,
    input  wire              start,

    output reg               psel,
    output reg               penable,
    output reg               pwrite,
    output reg  [7:0]        paddr,
    output reg  [31:0]       pwdata,

    output wire [N*8-1:0]    s_tdata,
    output wire              s_tvalid,
    input  wire              s_tready,
    output wire              s_tlast,

    input  wire [N*8-1:0]    m_tdata,
    input  wire              m_tvalid,
    output wire              m_tready,
    input  wire              m_tlast,

    output reg               busy,
    output reg               pass,
    output reg               fail
);
    localparam SHIFT = 4;
    localparam NCFG  = 3 + N;                 // CTRL, SHIFT, KLEN, N biases

    // ---------------- compile-time test vectors and reference ----------------
    function integer a_val(input integer r, input integer k);
        begin a_val = ((r*7 + k*3) % 17) - 8; end
    endfunction
    function integer w_val(input integer k, input integer c);
        begin w_val = ((k*5 + c*11) % 13) - 6; end
    endfunction
    function integer b_val(input integer c);
        begin b_val = c*100 - 300; end
    endfunction

    function [N*8*K-1:0] make_a(input integer dummy);
        integer k, r;
        begin
            make_a = 0;
            for (k = 0; k < K; k = k + 1)
                for (r = 0; r < N; r = r + 1)
                    make_a[(k*N + r)*8 +: 8] = a_val(r, k);
        end
    endfunction
    function [N*8*K-1:0] make_w(input integer dummy);
        integer k, c;
        begin
            make_w = 0;
            for (k = 0; k < K; k = k + 1)
                for (c = 0; c < N; c = c + 1)
                    make_w[(k*N + c)*8 +: 8] = w_val(k, c);
        end
    endfunction
    function [N*N*8-1:0] make_exp(input integer dummy);
        integer r, c, k, acc, v;
        begin
            make_exp = 0;
            for (r = 0; r < N; r = r + 1)
                for (c = 0; c < N; c = c + 1) begin
                    acc = 0;
                    for (k = 0; k < K; k = k + 1) acc = acc + a_val(r, k) * w_val(k, c);
                    v = acc + b_val(c);
                    v = (v + (1 << (SHIFT - 1))) >>> SHIFT;
                    if (v < 0)   v = 0;           // ReLU enabled
                    if (v > 127) v = 127;
                    make_exp[(r*N + c)*8 +: 8] = v;
                end
        end
    endfunction

    localparam [N*8*K-1:0] A_BEATS = make_a(0);
    localparam [N*8*K-1:0] W_BEATS = make_w(0);
    localparam [N*N*8-1:0] EXP     = make_exp(0);

    // ---------------- APB configuration ROM ----------------
    function [7:0] cfg_addr(input integer i);
        begin
            if (i == 0)      cfg_addr = 8'h00;
            else if (i == 1) cfg_addr = 8'h04;
            else if (i == 2) cfg_addr = 8'h08;
            else             cfg_addr = 8'h10 + 4*(i - 3);
        end
    endfunction
    function [31:0] cfg_data(input integer i);
        begin
            if (i == 0)      cfg_data = 32'd1;
            else if (i == 1) cfg_data = SHIFT;
            else if (i == 2) cfg_data = K;
            else             cfg_data = b_val(i - 3);
        end
    endfunction

    // ---------------- FSM ----------------
    localparam S_IDLE = 3'd0, S_CFG = 3'd1, S_SEND = 3'd2, S_RECV = 3'd3;

    reg [2:0]  st;
    reg [1:0]  ph;
    reg [4:0]  ci;
    reg [5:0]  si;
    reg [4:0]  ri;
    reg        bad;
    reg [3:0]  bp;
    reg [15:0] wd;

    assign s_tvalid = (st == S_SEND);
    assign s_tlast  = (si == 2*K - 1);
    assign s_tdata  = (si < K) ? A_BEATS[si*N*8 +: N*8] : W_BEATS[(si - K)*N*8 +: N*8];
    assign m_tready = (st == S_RECV) && bp[1];

    wire [N*8-1:0] exp_row = EXP[ri*N*8 +: N*8];
    wire           mism    = (m_tdata != exp_row) || (m_tlast != (ri == N - 1));
    wire           bad_n   = bad | mism;

    always @(posedge clk) begin
        bp <= bp + 1'b1;
        if (rst) begin
            st <= S_IDLE; ph <= 0; ci <= 0; si <= 0; ri <= 0; bad <= 0; wd <= 0; bp <= 0;
            psel <= 0; penable <= 0; pwrite <= 0; paddr <= 0; pwdata <= 0;
            busy <= 0; pass <= 0; fail <= 0;
        end else begin
            if (st != S_IDLE) wd <= wd + 1'b1; else wd <= 0;
            if (wd == 16'hFFFF) begin              // watchdog: NPU never answered
                st <= S_IDLE; busy <= 0; fail <= 1; pass <= 0;
                psel <= 0; penable <= 0; pwrite <= 0;
            end
            case (st)
                S_IDLE: if (start) begin
                    st <= S_CFG; ph <= 0; ci <= 0; si <= 0; ri <= 0; bad <= 0;
                    busy <= 1; pass <= 0; fail <= 0;
                end

                S_CFG: case (ph)
                    2'd0: begin
                        psel <= 1; penable <= 0; pwrite <= 1;
                        paddr <= cfg_addr(ci); pwdata <= cfg_data(ci);
                        ph <= 2'd1;
                    end
                    2'd1: begin penable <= 1; ph <= 2'd2; end
                    default: begin
                        psel <= 0; penable <= 0; pwrite <= 0; ph <= 2'd0;
                        if (ci == NCFG - 1) begin st <= S_SEND; si <= 0; end
                        else ci <= ci + 1'b1;
                    end
                endcase

                S_SEND: if (s_tready) begin
                    if (si == 2*K - 1) st <= S_RECV;
                    else si <= si + 1'b1;
                end

                S_RECV: if (m_tvalid && m_tready) begin
                    bad <= bad_n;
                    if (ri == N - 1) begin
                        pass <= ~bad_n; fail <= bad_n; busy <= 0; st <= S_IDLE;
                    end else ri <= ri + 1'b1;
                end

                default: st <= S_IDLE;
            endcase
        end
    end
endmodule

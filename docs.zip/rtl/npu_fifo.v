// Small synchronous first-word-fall-through FIFO (register array).
module npu_fifo #(
    parameter W  = 64,
    parameter AW = 4
) (
    input  wire          clk,
    input  wire          rst,
    input  wire          push,
    input  wire [W-1:0]  din,
    input  wire          pop,
    output wire [W-1:0]  dout,
    output wire          empty,
    output wire          full,
    output wire [AW:0]   count
);
    reg [W-1:0]  mem [0:(1<<AW)-1];
    reg [AW:0]   wp, rp;

    assign count = wp - rp;
    assign empty = (count == 0);
    assign full  = (count == (1 << AW));
    assign dout  = mem[rp[AW-1:0]];

    always @(posedge clk) begin
        if (rst) begin
            wp <= 0;
            rp <= 0;
        end else begin
            if (push && !full) begin
                mem[wp[AW-1:0]] <= din;
                wp <= wp + 1'b1;
            end
            if (pop && !empty) rp <= rp + 1'b1;
        end
    end
endmodule

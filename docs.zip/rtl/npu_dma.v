// Descriptor-driven DMA for the NPU core (Avalon-MM master, 64-bit data, N must be 8).
//
// Software builds a table of 64-byte descriptors in DDR, writes DESC_BASE / DESC_COUNT / START.
// For every descriptor the DMA
//   1. reads the descriptor (8 x 64-bit words),
//   2. reads K beats of A and K beats of W (8 bytes each) and streams them to the core,
//   3. writes the 8 result beats (64 bytes) back to out_addr.
// Reads are pipelined (many outstanding) and the next descriptor fetch overlaps the current tile's
// operand returns, compute and write-back.
//
// Descriptor layout (little-endian 64-bit words):
//   w0 : [31:0] a_addr   [63:32] w_addr        (byte addresses, 8-byte aligned)
//   w1 : [31:0] out_addr [39:32] K  [44:40] shift  [48] relu
//   w2..w5 : bias[0..7] as int32, two per word (bias[2i] in the low half)
//   w6,w7  : reserved
// A tile in memory = K words; word k holds A[0..7][k] (byte r = row r).
// W tile in memory = K words; word k holds W[k][0..7] (byte c = column c).
// Output tile      = 8 words; word r holds OUT[r][0..7].
module npu_dma #(
    parameter N    = 8,
    parameter KMAX = 32,
    parameter USE_WRITE_RESPONSE = 1
) (
    input  wire         clk,
    input  wire         rst,

    input  wire         start,
    input  wire [31:0]  desc_base,
    input  wire [15:0]  desc_count,
    output reg          busy,
    output reg          done_pulse,
    output reg          err_pulse,
    output reg  [15:0]  tiles_done,

    // Avalon-MM master
    output wire [31:0]  avm_address,
    output wire         avm_read,
    output wire         avm_write,
    output wire [63:0]  avm_writedata,
    output wire [7:0]   avm_byteenable,
    input  wire [63:0]  avm_readdata,
    input  wire         avm_readdatavalid,
    input  wire         avm_waitrequest,
    input  wire         avm_writeresponsevalid,

    // to / from the NPU core
    output wire [63:0]  s_tdata,
    output wire         s_tvalid,
    input  wire         s_tready,
    output wire         s_tlast,
    output wire         cfg_relu,
    output wire [4:0]   cfg_shift,
    output wire [7:0]   cfg_klen,
    output wire [255:0] cfg_bias,
    input  wire [63:0]  m_tdata,
    input  wire         m_tvalid,
    output wire         m_tready,
    input  wire         m_tlast
);
    localparam MW = 1 + 5 + 8 + 256;      // relu, shift, K, bias[8]

    // ---------------------------------------------------------------- FIFOs
    wire        tag_pop, tag_push, tag_din, tag_dout, tag_empty, tag_full;
    wire [5:0]  tag_cnt;
    npu_fifo #(.W(1), .AW(5)) u_tag (.clk(clk), .rst(rst), .push(tag_push), .din(tag_din),
        .pop(tag_pop), .dout(tag_dout), .empty(tag_empty), .full(tag_full), .count(tag_cnt));

    wire        df_push, df_pop, df_empty, df_full;
    wire [63:0] df_dout;
    wire [4:0]  df_cnt;
    npu_fifo #(.W(64), .AW(4)) u_data (.clk(clk), .rst(rst), .push(df_push), .din(avm_readdata),
        .pop(df_pop), .dout(df_dout), .empty(df_empty), .full(df_full), .count(df_cnt));

    wire          mf_push, mf_pop, mf_empty, mf_full;
    wire [MW-1:0] mf_din, mf_dout;
    wire [2:0]    mf_cnt;
    npu_fifo #(.W(MW), .AW(2)) u_meta (.clk(clk), .rst(rst), .push(mf_push), .din(mf_din),
        .pop(mf_pop), .dout(mf_dout), .empty(mf_empty), .full(mf_full), .count(mf_cnt));

    wire        oa_push, oa_pop, oa_empty, oa_full;
    wire [31:0] oa_din, oa_dout;
    wire [2:0]  oa_cnt;
    npu_fifo #(.W(32), .AW(2)) u_oaddr (.clk(clk), .rst(rst), .push(oa_push), .din(oa_din),
        .pop(oa_pop), .dout(oa_dout), .empty(oa_empty), .full(oa_full), .count(oa_cnt));

    wire        of_push, of_pop, of_empty, of_full;
    wire [63:0] of_dout;
    wire [3:0]  of_cnt;
    npu_fifo #(.W(64), .AW(3)) u_out (.clk(clk), .rst(rst), .push(of_push), .din(m_tdata),
        .pop(of_pop), .dout(of_dout), .empty(of_empty), .full(of_full), .count(of_cnt));

    // ---------------------------------------------------------------- input (read) engine
    localparam I_IDLE = 3'd0, I_DESC = 3'd1, I_WAIT = 3'd2, I_PARSE = 3'd3, I_OPD = 3'd4, I_FIN = 3'd5;

    reg [2:0]   ist;
    reg [3:0]   dw_i;
    reg [31:0]  dcur;
    reg [15:0]  dissued;
    reg [31:0]  a_addr_r, w_addr_r;
    reg [7:0]   k_r;
    reg [8:0]   opd_i;
    reg         in_done;
    reg [3:0]   dcnt;
    reg         desc_ready;
    reg [63:0]  dwd [0:7];
    reg [5:0]   outst;
    reg [5:0]   opd_out;
    reg [15:0]  tiles_pushed;
    reg [5:0]   wr_out;

    wire        outst_ok   = (outst < 6'd28);
    wire        dfifo_room = ({1'b0, df_cnt} + opd_out) < 7'd16;
    wire        rd_req     = ((ist == I_DESC) && outst_ok) ||
                             ((ist == I_OPD)  && outst_ok && dfifo_room);

    wire [31:0] opd_a_off  = {20'd0, opd_i, 3'b000};
    wire [8:0]  opd_w_idx  = opd_i - {1'b0, k_r};
    wire [31:0] opd_w_off  = {20'd0, opd_w_idx, 3'b000};
    wire [31:0] rd_addr    = (ist == I_DESC) ? (dcur + {25'd0, dw_i, 3'b000}) :
                             (opd_i < k_r)   ? (a_addr_r + opd_a_off) : (w_addr_r + opd_w_off);

    // parsed descriptor fields
    wire [63:0] d0 = dwd[0], d1 = dwd[1];
    wire [7:0]  p_k      = d1[39:32];
    wire [4:0]  p_shift  = d1[44:40];
    wire        p_relu   = d1[48];
    wire [255:0] p_bias  = {dwd[5], dwd[4], dwd[3], dwd[2]};
    wire        p_kok    = (p_k != 0) && (p_k <= KMAX);
    wire        parse_go = (ist == I_PARSE) && !mf_full && !oa_full;

    assign mf_push = parse_go && p_kok;
    assign mf_din  = {p_relu, p_shift, p_k, p_bias};
    assign oa_push = parse_go && p_kok;
    assign oa_din  = d1[31:0];

    // ---------------------------------------------------------------- Avalon arbitration (writes first)
    reg         lock_wr, lock_rd;
    wire        wr_req;
    wire [31:0] wr_addr;
    wire        sel_wr = lock_wr || (!lock_rd && wr_req);

    assign avm_write      = sel_wr;
    assign avm_read       = !sel_wr && rd_req;
    assign avm_address    = sel_wr ? wr_addr : rd_addr;
    assign avm_writedata  = of_dout;
    assign avm_byteenable = 8'hFF;

    wire rd_acc = avm_read  && !avm_waitrequest;
    wire wr_acc = avm_write && !avm_waitrequest;

    always @(posedge clk) begin
        if (rst) begin
            lock_wr <= 1'b0;
            lock_rd <= 1'b0;
        end else begin
            lock_wr <= avm_write && avm_waitrequest;
            lock_rd <= avm_read  && avm_waitrequest;
        end
    end

    // ---------------------------------------------------------------- read-return routing
    assign tag_push = rd_acc;
    assign tag_din  = (ist == I_OPD);                // 1 = operand beat, 0 = descriptor word
    assign tag_pop  = avm_readdatavalid;
    assign df_push  = avm_readdatavalid && tag_dout;

    // ---------------------------------------------------------------- stream stage
    reg           in_pkt;
    reg [8:0]     sbeat;
    reg [MW-1:0]  meta_cur;
    wire [MW-1:0] meta_sel = in_pkt ? meta_cur : mf_dout;

    assign cfg_bias  = meta_sel[255:0];
    assign cfg_klen  = meta_sel[263:256];
    assign cfg_shift = meta_sel[268:264];
    assign cfg_relu  = meta_sel[269];

    assign s_tvalid = !df_empty && (in_pkt || !mf_empty);
    assign s_tdata  = df_dout;
    assign s_tlast  = (sbeat == ({cfg_klen, 1'b0} - 9'd1));
    wire   s_acc    = s_tvalid && s_tready;
    assign df_pop   = s_acc;
    assign mf_pop   = s_acc && !in_pkt;

    always @(posedge clk) begin
        if (rst) begin
            in_pkt <= 1'b0;
            sbeat  <= 0;
        end else if (s_acc) begin
            if (!in_pkt) meta_cur <= mf_dout;
            if (s_tlast) begin in_pkt <= 1'b0; sbeat <= 0; end
            else         begin in_pkt <= 1'b1; sbeat <= sbeat + 1'b1; end
        end
    end

    // ---------------------------------------------------------------- output (write) engine
    reg [3:0] obeat;
    assign m_tready = !of_full;
    assign of_push  = m_tvalid && m_tready;
    assign wr_req   = !of_empty && !oa_empty;
    assign wr_addr  = oa_dout + {25'd0, obeat, 3'b000};
    assign of_pop   = wr_acc;
    assign oa_pop   = wr_acc && (obeat == N - 1);

    // ---------------------------------------------------------------- sequencing
    always @(posedge clk) begin
        done_pulse <= 1'b0;
        err_pulse  <= 1'b0;
        if (rst) begin
            ist <= I_IDLE; busy <= 1'b0; in_done <= 1'b0;
            dw_i <= 0; dcur <= 0; dissued <= 0; opd_i <= 0; k_r <= 0;
            dcnt <= 0; desc_ready <= 1'b0; outst <= 0; opd_out <= 0;
            tiles_pushed <= 0; tiles_done <= 0; wr_out <= 0; obeat <= 0;
        end else begin
            // outstanding-read bookkeeping
            outst   <= outst   + {5'd0, rd_acc} - {5'd0, avm_readdatavalid};
            opd_out <= opd_out + {5'd0, rd_acc && (ist == I_OPD)}
                               - {5'd0, avm_readdatavalid && tag_dout};

            // descriptor words coming back
            if (avm_readdatavalid && !tag_dout) begin
                dwd[dcnt] <= avm_readdata;
                dcnt      <= dcnt + 1'b1;
                if (dcnt == 4'd7) desc_ready <= 1'b1;
            end

            // write bookkeeping
            if (USE_WRITE_RESPONSE != 0)
                wr_out <= wr_out + {5'd0, wr_acc} - {5'd0, avm_writeresponsevalid};
            if (wr_acc) begin
                if (obeat == N - 1) begin obeat <= 0; tiles_done <= tiles_done + 1'b1; end
                else                obeat <= obeat + 1'b1;
            end

            case (ist)
                I_IDLE: if (start && !busy) begin
                    busy <= 1'b1; in_done <= 1'b0;
                    tiles_done <= 0; tiles_pushed <= 0;
                    dcur <= desc_base; dissued <= 0; dw_i <= 0;
                    dcnt <= 0; desc_ready <= 1'b0;
                    ist  <= (desc_count == 0) ? I_FIN : I_DESC;
                end

                I_DESC: if (rd_acc) begin
                    dw_i <= dw_i + 1'b1;
                    if (dw_i == 4'd7) ist <= I_WAIT;
                end

                I_WAIT: if (desc_ready) ist <= I_PARSE;

                I_PARSE: if (parse_go) begin
                    desc_ready <= 1'b0;
                    dcnt       <= 0;
                    if (!p_kok) begin
                        err_pulse <= 1'b1;               // bad descriptor: stop fetching, drain
                        ist       <= I_FIN;
                    end else begin
                        tiles_pushed <= tiles_pushed + 1'b1;
                        a_addr_r <= d0[31:0];
                        w_addr_r <= d0[63:32];
                        k_r      <= p_k;
                        opd_i    <= 0;
                        ist      <= I_OPD;
                    end
                end

                I_OPD: if (rd_acc) begin
                    opd_i <= opd_i + 1'b1;
                    if (opd_i == ({k_r, 1'b0} - 9'd1)) begin
                        dissued <= dissued + 1'b1;
                        if (dissued + 1'b1 == desc_count) ist <= I_FIN;
                        else begin
                            dcur <= dcur + 32'd64;
                            dw_i <= 0;
                            ist  <= I_DESC;
                        end
                    end
                end

                I_FIN: begin
                    in_done <= 1'b1;
                    ist     <= I_IDLE;
                end

                default: ist <= I_IDLE;
            endcase

            // completion: every pushed tile written back and acknowledged
            if (busy && in_done && ist == I_IDLE && !start &&
                tiles_done == tiles_pushed && wr_out == 0 && of_empty) begin
                busy       <= 1'b0;
                in_done    <= 1'b0;
                done_pulse <= 1'b1;
            end
        end
    end
endmodule

// NPU software interface: register map, DDR data layout, descriptor builder, reference model.
// Everything here is plain C so the same code runs on the ARM (Linux) and on the host (test vectors).
#ifndef NPU_H
#define NPU_H

#include <stdint.h>

#define NPU_N      8
#define NPU_KMAX   32

// ---- CSR word indices (32-bit registers, accessed through the lightweight HPS-to-FPGA bridge)
enum {
    NPU_CTRL        = 0,   // [0] start (self-clearing)  [1] irq enable
    NPU_DESC_BASE   = 1,   // physical address of the descriptor table (64-byte aligned)
    NPU_DESC_COUNT  = 2,   // number of descriptors (tiles)
    NPU_STATUS      = 3,   // [0] busy  [1] done (W1C)  [2] error (W1C)
    NPU_TILES_DONE  = 4,
    NPU_TILE_CYCLES = 5,   // compute cycles of the most recent tile
    NPU_RUN_CYCLES  = 6,   // clocks from start to done of the last run
    NPU_ID          = 7
};
#define NPU_ID_VALUE   0x4E505532u
#define NPU_ST_BUSY    0x1u
#define NPU_ST_DONE    0x2u
#define NPU_ST_ERR     0x4u

// ---- descriptor (64 bytes = 8 little-endian 64-bit words)
//   w0 : [31:0] A address   [63:32] W address         (byte addresses, 8-byte aligned)
//   w1 : [31:0] out address [39:32] K  [44:40] shift  [48] relu
//   w2..w5 : bias[0..7], int32, bias[2i] in the low half of word 2+i
typedef struct { uint64_t w[8]; } npu_desc_t;

static inline void npu_make_desc(npu_desc_t *d, uint32_t a_addr, uint32_t w_addr, uint32_t out_addr,
                                 int K, int shift, int relu, const int32_t bias[8])
{
    int i;
    for (i = 0; i < 8; i++) d->w[i] = 0;
    d->w[0] = (uint64_t)a_addr | ((uint64_t)w_addr << 32);
    d->w[1] = (uint64_t)out_addr | ((uint64_t)(K & 0xFF) << 32) |
              ((uint64_t)(shift & 0x1F) << 40) | ((uint64_t)(relu & 1) << 48);
    for (i = 0; i < 4; i++)
        d->w[2 + i] = (uint64_t)(uint32_t)bias[2 * i] | ((uint64_t)(uint32_t)bias[2 * i + 1] << 32);
}

// ---- operand layout.  A tile = K words, word k byte r = A[r0 + r][k].
//                       W tile = K words, word k byte c = W[k][c0 + c].
//      Output tile = 8 words, word r byte c = OUT[r][c].
// Bytes are placed with shifts, so the result is correct on any host endianness.
static inline void npu_pack_a(uint64_t *dst, const int8_t *A, int lda, int r0, int K)
{
    int k, r;
    for (k = 0; k < K; k++) {
        uint64_t w = 0;
        for (r = 0; r < NPU_N; r++) w |= (uint64_t)(uint8_t)A[(r0 + r) * lda + k] << (8 * r);
        dst[k] = w;
    }
}

static inline void npu_pack_w(uint64_t *dst, const int8_t *W, int ldw, int c0, int K)
{
    int k, c;
    for (k = 0; k < K; k++) {
        uint64_t w = 0;
        for (c = 0; c < NPU_N; c++) w |= (uint64_t)(uint8_t)W[k * ldw + c0 + c] << (8 * c);
        dst[k] = w;
    }
}

static inline int8_t npu_unpack_out(const uint64_t *tile, int r, int c)
{
    return (int8_t)((tile[r] >> (8 * c)) & 0xFF);
}

// ---- bit-exact reference of the hardware post-processing:
//      v = acc + bias; v = (v + (1 << (shift-1))) >> shift (arithmetic); optional ReLU; clamp to int8
static inline int8_t npu_requant(int64_t acc, int32_t bias, int shift, int relu)
{
    int64_t v = acc + bias;
    if (shift > 0) v = (v + ((int64_t)1 << (shift - 1))) >> shift;
    if (relu && v < 0) v = 0;
    if (v > 127) v = 127;
    if (v < -128) v = -128;
    return (int8_t)v;
}

static inline void npu_ref_tile(int8_t out[NPU_N][NPU_N], const int8_t *A, int lda, int r0,
                                const int8_t *W, int ldw, int c0, int K,
                                const int32_t bias[8], int shift, int relu)
{
    int r, c, k;
    for (r = 0; r < NPU_N; r++)
        for (c = 0; c < NPU_N; c++) {
            int64_t acc = 0;
            for (k = 0; k < K; k++) acc += (int)A[(r0 + r) * lda + k] * (int)W[k * ldw + c0 + c];
            out[r][c] = npu_requant(acc, bias[c], shift, relu);
        }
}

#endif

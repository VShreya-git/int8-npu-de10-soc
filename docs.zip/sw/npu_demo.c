// Linux userspace demo for the DE10-Standard (ARM Cortex-A9 + Cyclone V FPGA).
//
// Runs one int8 layer  C[64x64] = requant( A[64x32] x W[32x64] + bias )  as 64 tiles on the NPU through its DMA,
// checks every output byte against a software reference, and compares the time with the ARM doing the same work.
//
// Needs root (uses /dev/mem). Prerequisites (see fpga/de10_soc/README_SOC.md):
//   * the FPGA is programmed with the Platform Designer system that contains the npu_soc component,
//   * Linux is booted with fewer than BUF_PHYS bytes of RAM (e.g. mem=768M) so BUF_PHYS.. is free for the NPU,
//   * NPU_OFFSET below matches the base address you assigned to the NPU CSR slave on the lightweight bridge.
#define _GNU_SOURCE
#include "npu.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#define LW_BRIDGE_BASE  0xFF200000u        // HPS-to-FPGA lightweight bridge
#define LW_BRIDGE_SPAN  0x00200000u
#ifndef NPU_OFFSET
#define NPU_OFFSET      0x00000000u        // base address of the NPU CSR slave inside the bridge
#endif
#ifndef BUF_PHYS
#define BUF_PHYS        0x30000000u        // DDR region reserved for the NPU (needs mem=768M or less)
#endif
#define BUF_SIZE        0x01000000u        // 16 MB
#ifndef NPU_CLK_HZ
#define NPU_CLK_HZ      50000000.0         // FPGA clock driving the NPU
#endif

#define M    64
#define KD   32
#define NC   64
#define REPS 50

#define DESC_OFF   0x00000u                // descriptor table
#define OPD_OFF    0x10000u                // operands: tile t at OPD_OFF + t*1024 (A) and +512 (W)
#define OUT_OFF    0x100000u               // results: tile t at OUT_OFF + t*64

static volatile uint32_t *regs;
static inline uint32_t rd32(int idx) { return regs[idx]; }
static inline void     wr32(int idx, uint32_t v) { regs[idx] = v; __sync_synchronize(); }

static double now_s(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static uint32_t lcg = 12345;
static int rs8(void) { lcg = lcg * 1664525u + 1013904223u; return (int)((lcg >> 16) % 256) - 128; }

int main(void)
{
    int fd = open("/dev/mem", O_RDWR | O_SYNC);       // O_SYNC: uncached mapping, no cache maintenance needed
    if (fd < 0) { perror("open /dev/mem (run as root)"); return 1; }

    void *lw = mmap(NULL, LW_BRIDGE_SPAN, PROT_READ | PROT_WRITE, MAP_SHARED, fd, LW_BRIDGE_BASE);
    void *bf = mmap(NULL, BUF_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, BUF_PHYS);
    if (lw == MAP_FAILED || bf == MAP_FAILED) { perror("mmap"); return 1; }
    regs = (volatile uint32_t *)((uint8_t *)lw + NPU_OFFSET);
    uint8_t *buf = (uint8_t *)bf;

    if (rd32(NPU_ID) != NPU_ID_VALUE) {
        fprintf(stderr, "NPU ID mismatch: read 0x%08x, expected 0x%08x.\n"
                        "Check the FPGA image and NPU_OFFSET (currently 0x%x).\n",
                rd32(NPU_ID), NPU_ID_VALUE, (unsigned)NPU_OFFSET);
        return 1;
    }

    // ---- random layer
    static int8_t A[M * KD], W[KD * NC], Cref[M * NC], Cnpu[M * NC];
    int32_t bias[NC];
    int shift = 10, relu = 1;
    int i, r, c, k, mt, nt;
    for (i = 0; i < M * KD; i++)  A[i] = (int8_t)rs8();
    for (i = 0; i < KD * NC; i++) W[i] = (int8_t)rs8();
    for (i = 0; i < NC; i++)      bias[i] = rs8() * 40;

    // ---- software baseline on the ARM
    double t0 = now_s();
    for (int rep = 0; rep < REPS; rep++)
        for (r = 0; r < M; r++)
            for (c = 0; c < NC; c++) {
                int64_t acc = 0;
                for (k = 0; k < KD; k++) acc += A[r * KD + k] * W[k * NC + c];
                Cref[r * NC + c] = npu_requant(acc, bias[c], shift, relu);
            }
    double t_sw = (now_s() - t0) / REPS;

    // ---- build the descriptor table and operand tiles in the reserved DDR region
    int ntiles = (M / NPU_N) * (NC / NPU_N);
    double tp0 = now_s();
    for (mt = 0; mt < M / NPU_N; mt++)
        for (nt = 0; nt < NC / NPU_N; nt++) {
            int t = mt * (NC / NPU_N) + nt;
            uint32_t a_off = OPD_OFF + t * 1024, w_off = a_off + 512, o_off = OUT_OFF + t * 64;
            npu_pack_a((uint64_t *)(buf + a_off), A, KD, mt * NPU_N, KD);
            npu_pack_w((uint64_t *)(buf + w_off), W, NC, nt * NPU_N, KD);
            npu_desc_t d;
            npu_make_desc(&d, BUF_PHYS + a_off, BUF_PHYS + w_off, BUF_PHYS + o_off, KD, shift, relu,
                          &bias[nt * NPU_N]);
            memcpy(buf + DESC_OFF + t * 64, d.w, 64);
        }
    double t_pack = now_s() - tp0;

    // ---- run on the NPU (repeat to average; results are rewritten every run)
    double t_npu_total = 0;
    uint32_t cyc = 0;
    for (int rep = 0; rep < REPS; rep++) {
        wr32(NPU_STATUS, NPU_ST_DONE | NPU_ST_ERR);           // clear sticky flags
        wr32(NPU_DESC_BASE, BUF_PHYS + DESC_OFF);
        wr32(NPU_DESC_COUNT, ntiles);
        double ts = now_s();
        wr32(NPU_CTRL, 1);                                    // start
        uint32_t st;
        long spin = 0;
        while (!((st = rd32(NPU_STATUS)) & (NPU_ST_DONE | NPU_ST_ERR)) && ++spin < 50000000L) ;
        t_npu_total += now_s() - ts;
        if (st & NPU_ST_ERR) { fprintf(stderr, "NPU reported an error (STATUS=0x%x)\n", st); return 1; }
        if (!(st & NPU_ST_DONE)) { fprintf(stderr, "timeout waiting for NPU (STATUS=0x%x)\n", st); return 1; }
        cyc = rd32(NPU_RUN_CYCLES);
    }
    double t_npu = t_npu_total / REPS;

    // ---- read back and verify
    int bad = 0;
    for (mt = 0; mt < M / NPU_N; mt++)
        for (nt = 0; nt < NC / NPU_N; nt++) {
            const uint64_t *tile = (const uint64_t *)(buf + OUT_OFF + (mt * (NC / NPU_N) + nt) * 64);
            for (r = 0; r < NPU_N; r++)
                for (c = 0; c < NPU_N; c++)
                    Cnpu[(mt * NPU_N + r) * NC + nt * NPU_N + c] = npu_unpack_out(tile, r, c);
        }
    for (i = 0; i < M * NC; i++) if (Cnpu[i] != Cref[i]) bad++;

    double macs = (double)M * KD * NC;
    printf("layer %dx%dx%d  (%d tiles of 8x8, K=%d)\n", M, KD, NC, ntiles, KD);
    printf("result check      : %s (%d of %d bytes differ)\n", bad ? "FAIL" : "PASS", bad, M * NC);
    printf("ARM software      : %8.1f us   (%.3f GMAC/s)\n", t_sw * 1e6, macs / t_sw / 1e9);
    printf("NPU (wall clock)  : %8.1f us   (%.3f GMAC/s)  speedup %.1fx\n",
           t_npu * 1e6, macs / t_npu / 1e9, t_sw / t_npu);
    printf("NPU (HW counter)  : %u cycles = %.1f us @ %.0f MHz  (%.1f cycles/tile)\n",
           cyc, cyc / NPU_CLK_HZ * 1e6, NPU_CLK_HZ / 1e6, (double)cyc / ntiles);
    printf("packing on ARM    : %8.1f us (one-time, not included above)\n", t_pack * 1e6);
    return bad ? 2 : 0;
}

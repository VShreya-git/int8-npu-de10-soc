// Generates a DDR image + expected results using the SAME C packing code the Linux driver uses,
// so the RTL testbench (tb/tb_swvec.v) proves the software data layout matches the hardware.
//
// usage: gen_vectors <ntiles> <seed> <mem.hex> <exp.hex>
//   mem.hex : descriptors at byte 0, operands at 0x4000 + n*1024 (A) / +512 (W)
//   exp.hex : expected output words (8 per tile), compared against DDR at 0x80000 + n*64
#include "npu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint32_t rng_state = 1;
static uint32_t rnd(void) { rng_state = rng_state * 1664525u + 1013904223u; return rng_state >> 8; }
static int rs8(void) { return (int)(rnd() % 256) - 128; }

#define MAXT   64
#define MEMW   (1 << 17)
#define DESC0  0x0u
#define DATA0  0x4000u
#define OUT0   0x80000u

int main(int argc, char **argv)
{
    if (argc != 5) { fprintf(stderr, "usage: %s ntiles seed mem.hex exp.hex\n", argv[0]); return 1; }
    int nt = atoi(argv[1]);
    rng_state = (uint32_t)atoi(argv[2]);
    if (nt < 1 || nt > MAXT) { fprintf(stderr, "ntiles 1..%d\n", MAXT); return 1; }

    uint64_t *mem = calloc(MEMW, sizeof(uint64_t));
    uint64_t *exp = calloc(MAXT * 8, sizeof(uint64_t));
    int n, r, c, k;

    for (n = 0; n < nt; n++) {
        int K = (n % 5 == 0) ? NPU_KMAX : (n == 1 ? 1 : 1 + (int)(rnd() % NPU_KMAX));
        int shift = (int)(rnd() % 14), relu = (int)(rnd() % 2);
        int8_t A[NPU_N * NPU_KMAX], W[NPU_KMAX * NPU_N];
        int32_t bias[8];
        for (r = 0; r < NPU_N; r++) for (k = 0; k < K; k++) A[r * K + k] = (int8_t)rs8();
        for (k = 0; k < K; k++) for (c = 0; c < NPU_N; c++) W[k * NPU_N + c] = (int8_t)rs8();
        for (c = 0; c < 8; c++) bias[c] = (int32_t)(rnd() % 20001) - 10000;

        uint32_t a_addr = DATA0 + n * 1024, w_addr = a_addr + 512, o_addr = OUT0 + n * 64;
        npu_pack_a(&mem[a_addr / 8], A, K, 0, K);              // lda = K here
        npu_pack_w(&mem[w_addr / 8], W, NPU_N, 0, K);          // ldw = 8 here
        npu_desc_t d;
        npu_make_desc(&d, a_addr, w_addr, o_addr, K, shift, relu, bias);
        memcpy(&mem[(DESC0 + n * 64) / 8], d.w, 64);

        int8_t out[NPU_N][NPU_N];
        npu_ref_tile(out, A, K, 0, W, NPU_N, 0, K, bias, shift, relu);
        for (r = 0; r < NPU_N; r++) {
            uint64_t w = 0;
            for (c = 0; c < NPU_N; c++) w |= (uint64_t)(uint8_t)out[r][c] << (8 * c);
            exp[n * 8 + r] = w;
        }
    }

    FILE *f = fopen(argv[3], "w");
    if (!f) { perror(argv[3]); return 1; }
    for (n = 0; n < (int)((DATA0 + MAXT * 1024) / 8); n++) fprintf(f, "%016llx\n", (unsigned long long)mem[n]);
    fclose(f);
    f = fopen(argv[4], "w");
    if (!f) { perror(argv[4]); return 1; }
    for (n = 0; n < nt * 8; n++) fprintf(f, "%016llx\n", (unsigned long long)exp[n]);
    fclose(f);
    return 0;
}
